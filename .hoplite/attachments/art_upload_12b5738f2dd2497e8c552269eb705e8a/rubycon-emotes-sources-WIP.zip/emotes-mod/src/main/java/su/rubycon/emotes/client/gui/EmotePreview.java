package su.rubycon.emotes.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.joml.Quaternionf;
import su.rubycon.emotes.client.ClientEmotes;
import su.rubycon.emotes.client.EmoteDefs;

/** Renders the local player in a box with an emote playing in a loop. */
public final class EmotePreview {
    public float rotY = -25, rotX = -8;
    private String lastId;
    private static final float PAUSE = 0.7f;

    public void restart() { lastId = null; }

    public void render(GuiGraphics g, int x, int y, int w, int h, String id, boolean helmet) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        Ui.box(g, x, y, w, h, 0xFF0E0C10, Ui.BORDER);
        // soft vignette floor
        g.fillGradient(x + 1, y + h / 2, x + w - 1, y + h - 1, 0x00000000, 0x40D6334F);
        if (p == null) return;
        EmoteDefs.Def def = id == null ? null : EmoteDefs.get(id);
        long now = System.nanoTime();
        if (id != null && !id.equals(lastId)) { lastId = id; ClientEmotes.previewStart = now; }
        float dur = def != null ? def.duration : 3f;
        if ((now - ClientEmotes.previewStart) / 1e9f > dur + PAUSE) ClientEmotes.previewStart = now;

        float yb = p.yBodyRot, yr = p.getYRot(), xr = p.getXRot(), yho = p.yHeadRotO, yh = p.yHeadRot, ybo = p.yBodyRotO;
        ItemStack oldHead = p.getInventory().armor.get(3);
        int scale = Math.round(Math.min(w * 0.42f, h * 0.40f));
        int cx = x + w / 2, cy = y + Math.round(h * 0.54f) + Math.round(scale * 1.75f);
        g.enableScissor(x + 1, y + 1, x + w - 1, y + h - 1);
        try {
            if (helmet) p.getInventory().armor.set(3, new ItemStack(Items.IRON_HELMET));
            else p.getInventory().armor.set(3, ItemStack.EMPTY);
            ClientEmotes.previewEntity = p.getId();
            ClientEmotes.previewId = id;
            ClientEmotes.previewDuration = Math.round(dur * 1000);
            Quaternionf pose = new Quaternionf().rotateZ((float) Math.PI);
            Quaternionf cam = new Quaternionf().rotateX((float) Math.toRadians(rotX));
            pose.mul(cam);
            p.yBodyRot = 180 + rotY; p.yBodyRotO = p.yBodyRot;
            p.setYRot(180 + rotY);
            p.setXRot(0);
            p.yHeadRot = p.getYRot(); p.yHeadRotO = p.getYRot();
            InventoryScreen.renderEntityInInventory(g, cx, cy, scale, pose, cam, p);
        } finally {
            p.yBodyRot = yb; p.yBodyRotO = ybo; p.setYRot(yr); p.setXRot(xr); p.yHeadRotO = yho; p.yHeadRot = yh;
            p.getInventory().armor.set(3, oldHead);
            ClientEmotes.previewEntity = Integer.MIN_VALUE; ClientEmotes.previewId = null;
            g.disableScissor();
        }
    }

    public void drag(double dx, double dy) {
        rotY = (rotY + (float) dx * 1.6f) % 360;
        rotX = Math.max(-35, Math.min(35, rotX - (float) dy * 0.8f));
    }
}
