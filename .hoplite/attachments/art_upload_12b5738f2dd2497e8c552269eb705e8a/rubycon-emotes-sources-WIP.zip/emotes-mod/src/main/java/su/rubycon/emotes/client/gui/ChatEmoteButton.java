package su.rubycon.emotes.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import org.lwjgl.glfw.GLFW;
import su.rubycon.emotes.EmotesConfig;
import su.rubycon.emotes.RubyconEmotes;
import su.rubycon.emotes.client.ClientEmotes;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Adds a ☺ button at the right end of the chat input of any ChatScreen (vanilla, Rubycon UI chat, roleplay chat).
 * The input is shortened by 16px to make room. Clicking opens a compact emote picker with a live preview.
 */
public final class ChatEmoteButton {
    private static final ResourceLocation TEX = new ResourceLocation(RubyconEmotes.MODID, "textures/gui/chat_button.png");
    private static final int BTN = 12, SHRINK = 16, CELL = 22, COLS = 5, ROWS = 4, PREV_W = 84;
    private static Field inputField;
    private static final Map<EditBox, int[]> WIDTHS = new WeakHashMap<>();   // {base, adjusted}

    private static Screen owner;
    private static boolean open, favTab, dragging;
    private static final EmotePreview PREVIEW = new EmotePreview();
    private static String hoverId;
    private static long openedAt;

    private static EditBox input(Screen s) {
        if (!(s instanceof ChatScreen)) return null;
        try {
            if (inputField == null) inputField = ObfuscationReflectionHelper.findField(ChatScreen.class, "f_95573_");
            return (EditBox) inputField.get(s);
        } catch (Throwable t) { return null; }
    }

    private static boolean enabled(Screen s) { return EmotesConfig.CHAT_BUTTON.get() && s instanceof ChatScreen; }

    /** Button rectangle or null if the input is not visible. */
    private static int[] button(Screen s, EditBox in) {
        if (in == null || !in.isVisible()) return null;
        int[] w = WIDTHS.get(in);
        int base = w != null ? w[0] : in.getWidth();
        int x = in.getX() + base - BTN - 1;
        int y = in.getY() + (in.getHeight() - BTN) / 2;
        if (s.getClass() == ChatScreen.class) y = in.getY() - 2 + (12 - BTN) / 2 - 1;   // vanilla box is 2px higher
        return new int[]{x, y, BTN, BTN};
    }

    private static List<String> list() {
        List<String> out = new ArrayList<>();
        if (favTab) out.addAll(ClientEmotes.favorites());
        else for (var e : ClientEmotes.entries()) out.add(e.id());
        return out;
    }

    private static int[] popup(Screen s, int[] b) {
        int w = COLS * CELL + 10 + PREV_W + 4, h = ROWS * CELL + 10 + 18 + 14;
        int x = Math.min(b[0] + b[2] - w + 4, s.width - w - 2), y = b[1] - h - 6;
        x = Math.max(2, x); y = Math.max(2, y);
        return new int[]{x, y, w, h};
    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void preRender(ScreenEvent.Render.Pre e) {
        Screen s = e.getScreen();
        if (!(s instanceof ChatScreen)) return;
        if (owner != s) { owner = s; open = false; }
        EditBox in = input(s);
        if (in == null) return;
        int[] w = WIDTHS.get(in);
        boolean on = enabled(s);
        if (w == null || in.getWidth() != w[1]) { w = new int[]{in.getWidth(), in.getWidth()}; WIDTHS.put(in, w); }
        int target = on && in.isVisible() ? w[0] - SHRINK : w[0];
        if (in.getWidth() != target) { in.setWidth(target); w[1] = target; }
    }

    @SubscribeEvent
    public static void postRender(ScreenEvent.Render.Post e) {
        Screen s = e.getScreen();
        if (!enabled(s)) return;
        EditBox in = input(s);
        int[] b = button(s, in);
        if (b == null) { open = false; return; }
        GuiGraphics g = e.getGuiGraphics();
        Font font = Minecraft.getInstance().font;
        int mx = e.getMouseX(), my = e.getMouseY();
        g.pose().pushPose();
        g.pose().translate(0, 0, 400);
        boolean hv = Ui.in(mx, my, b[0], b[1], b[2], b[3]);
        g.blit(TEX, b[0], b[1], (hv || open) ? 12 : 0, 0, 12, 12, 24, 12);
        if (open) drawPopup(g, font, s, b, mx, my);
        else if (hv) g.renderTooltip(font, Component.literal("Эмоции · ПКМ — меню"), mx, my);
        g.pose().popPose();
    }

    private static void drawPopup(GuiGraphics g, Font font, Screen s, int[] b, int mx, int my) {
        int[] p = popup(s, b);
        float t = Math.min(1, (System.currentTimeMillis() - openedAt) / 110f);
        g.pose().pushPose();
        g.pose().translate(0, (1 - t) * 6, 0);
        Ui.panel(g, p[0], p[1], p[2], p[3]);
        // tabs
        int tx = p[0] + 5, ty = p[1] + 5;
        tab(g, font, tx, ty, "Все", !favTab, mx, my);
        tab(g, font, tx + font.width("Все") + 14, ty, "★", favTab, mx, my);
        String more = "Меню ⚙";
        int mw = font.width(more) + 8, mxp = p[0] + COLS * CELL + 5 - mw;
        boolean mh = Ui.in(mx, my, mxp, ty, mw, 13);
        Ui.box(g, mxp, ty, mw, 13, mh ? Ui.CELL_HOVER : Ui.CELL, 0);
        g.drawString(font, more, mxp + 4, ty + 3, mh ? Ui.TEXT : Ui.MUTED, false);

        List<String> l = list();
        hoverId = null;
        int gx = p[0] + 5, gy = p[1] + 23;
        for (int i = 0; i < COLS * ROWS; i++) {
            int cx = gx + (i % COLS) * CELL, cy = gy + (i / COLS) * CELL;
            if (i >= l.size()) { if (favTab) Ui.box(g, cx + 1, cy + 1, CELL - 2, CELL - 2, 0x30201A24, 0); continue; }
            String id = l.get(i);
            boolean hv = Ui.in(mx, my, cx, cy, CELL, CELL), ok = EmoteMenuScreen.allowed(id);
            if (hv) hoverId = id;
            Ui.box(g, cx + 1, cy + 1, CELL - 2, CELL - 2, hv ? Ui.CELL_HOVER : Ui.CELL, hv ? Ui.ACCENT : 0);
            float sc = hv ? 1.12f : 1f;
            g.pose().pushPose();
            g.pose().translate(cx + CELL / 2f, cy + CELL / 2f, 0); g.pose().scale(sc, sc, 1);
            Ui.icon(g, id, -9, -9, 18, ok ? 1f : 0.3f);
            g.pose().popPose();
            if (ClientEmotes.favorite(id) && !favTab) {
                g.pose().pushPose(); g.pose().translate(cx + CELL - 7, cy + 1, 0); g.pose().scale(0.6f, 0.6f, 1);
                Ui.star(g, font, 0, 0, true); g.pose().popPose();
            }
        }
        if (favTab && l.isEmpty()) {
            g.drawCenteredString(font, "ПКМ по эмоции —", gx + COLS * CELL / 2, gy + 30, Ui.MUTED);
            g.drawCenteredString(font, "в избранное", gx + COLS * CELL / 2, gy + 41, Ui.MUTED);
        }
        // preview
        int px = p[0] + p[2] - PREV_W - 5, py = p[1] + 5, ph = p[3] - 10 - 14;
        String show = hoverId != null ? hoverId : (ClientEmotes.own() != null ? ClientEmotes.own().id() : null);
        PREVIEW.render(g, px, py, PREV_W, ph, show, false);
        // footer
        String foot;
        float cd = ClientEmotes.cooldownLeft();
        if (hoverId != null) foot = EmoteMenuScreen.name(hoverId) + (EmoteMenuScreen.allowed(hoverId) ? "" : " (недоступна)");
        else if (cd > 0) foot = String.format(java.util.Locale.ROOT, "Перезарядка %.1f с", cd);
        else foot = "ЛКМ — показать · ПКМ — ★";
        g.fill(p[0] + 1, p[1] + p[3] - 15, p[0] + p[2] - 1, p[1] + p[3] - 14, Ui.BORDER);
        g.drawString(font, foot, p[0] + 6, p[1] + p[3] - 11, hoverId != null ? Ui.TEXT : Ui.MUTED, false);
        boolean own = ClientEmotes.own() != null;
        if (own) {
            String c = "✖ Отменить";
            int cw = font.width(c), cx = p[0] + p[2] - cw - 6;
            boolean ch = Ui.in(mx, my, cx - 2, p[1] + p[3] - 13, cw + 4, 12);
            g.drawString(font, c, cx, p[1] + p[3] - 11, ch ? 0xFFFF7088 : Ui.MUTED, false);
        }
        g.pose().popPose();
    }

    private static void tab(GuiGraphics g, Font font, int x, int y, String s, boolean on, int mx, int my) {
        int w = font.width(s) + 10;
        boolean hv = Ui.in(mx, my, x, y, w, 13);
        Ui.box(g, x, y, w, 13, on ? Ui.ACCENT : hv ? Ui.CELL_HOVER : Ui.CELL, 0);
        g.drawString(font, s, x + 5, y + 3, on ? 0xFFFFFFFF : (s.equals("★") ? Ui.GOLD : Ui.MUTED), false);
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void click(ScreenEvent.MouseButtonPressed.Pre e) {
        Screen s = e.getScreen();
        if (!enabled(s)) return;
        int[] b = button(s, input(s));
        if (b == null) return;
        double mx = e.getMouseX(), my = e.getMouseY();
        int btn = e.getButton();
        if (Ui.in(mx, my, b[0], b[1], b[2], b[3])) {
            e.setCanceled(true);
            if (btn == 1) { Minecraft.getInstance().setScreen(new EmoteMenuScreen()); return; }
            open = !open; owner = s; openedAt = System.currentTimeMillis(); PREVIEW.restart();
            return;
        }
        if (!open) return;
        int[] p = popup(s, b);
        if (!Ui.in(mx, my, p[0], p[1], p[2], p[3])) { open = false; return; }
        e.setCanceled(true);
        Font font = Minecraft.getInstance().font;
        int tx = p[0] + 5, ty = p[1] + 5;
        if (Ui.in(mx, my, tx, ty, font.width("Все") + 10, 13)) { favTab = false; return; }
        if (Ui.in(mx, my, tx + font.width("Все") + 14, ty, font.width("★") + 10, 13)) { favTab = true; return; }
        int mw = font.width("Меню ⚙") + 8, mxp = p[0] + COLS * CELL + 5 - mw;
        if (Ui.in(mx, my, mxp, ty, mw, 13)) { Minecraft.getInstance().setScreen(new EmoteMenuScreen()); return; }
        if (ClientEmotes.own() != null) {
            String c = "✖ Отменить";
            int cw = font.width(c), cx = p[0] + p[2] - cw - 6;
            if (Ui.in(mx, my, cx - 2, p[1] + p[3] - 13, cw + 4, 12)) { ClientEmotes.cancel(); return; }
        }
        List<String> l = list();
        int gx = p[0] + 5, gy = p[1] + 23;
        for (int i = 0; i < Math.min(l.size(), COLS * ROWS); i++) {
            int cx = gx + (i % COLS) * CELL, cy = gy + (i / COLS) * CELL;
            if (!Ui.in(mx, my, cx, cy, CELL, CELL)) continue;
            String id = l.get(i);
            if (btn == 1) ClientEmotes.toggleFavorite(id);
            else if (ClientEmotes.request(id)) open = false;
            return;
        }
        int px = p[0] + p[2] - PREV_W - 5;
        if (Ui.in(mx, my, px, p[1] + 5, PREV_W, p[3] - 24)) dragging = true;
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void drag(ScreenEvent.MouseDragged.Pre e) {
        if (open && dragging && enabled(e.getScreen())) { PREVIEW.drag(e.getDragX(), e.getDragY()); e.setCanceled(true); }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void release(ScreenEvent.MouseButtonReleased.Pre e) {
        if (dragging) { dragging = false; e.setCanceled(true); }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void scroll(ScreenEvent.MouseScrolled.Pre e) {
        Screen s = e.getScreen();
        if (!open || !enabled(s)) return;
        int[] b = button(s, input(s));
        if (b == null) return;
        int[] p = popup(s, b);
        if (Ui.in(e.getMouseX(), e.getMouseY(), p[0], p[1], p[2], p[3])) e.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void key(ScreenEvent.KeyPressed.Pre e) {
        if (open && e.getKeyCode() == GLFW.GLFW_KEY_ESCAPE && enabled(e.getScreen())) { open = false; e.setCanceled(true); }
    }
}
