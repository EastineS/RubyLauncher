package su.rubycon.emotes.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.world.entity.EquipmentSlot;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import su.rubycon.emotes.EmotesConfig;

/**
 * Draws the emote of a player. Runs inside the player renderer, so the head transform already contains
 * crouching, swimming, sleeping, riding, model scale etc. Face layers are drawn in head space (they turn with
 * the head); billboard layers are anchored in head space but always face the viewer.
 */
public final class EmoteLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final EmoteAnimator.Quad Q = new EmoteAnimator.Quad();
    private static final Vector4f V = new Vector4f();

    public EmoteLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) { super(parent); }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer p, float limb, float limbAmt,
                       float partial, float age, float headYaw, float headPitch) {
        Minecraft mc = Minecraft.getInstance();
        boolean gui = RenderSystem.getProjectionMatrix().m33() != 0f;   // orthographic = drawn in a screen
        boolean preview = gui && p.getId() == ClientEmotes.previewEntity && ClientEmotes.previewId != null;
        String id; float t; float dur;
        if (preview) {
            id = ClientEmotes.previewId; dur = ClientEmotes.previewDuration / 1000f;
            t = (System.nanoTime() - ClientEmotes.previewStart) / 1e9f;
            if (t > dur) return;                                   // pause between preview loops
        } else {
            ClientEmotes.Active a = ClientEmotes.active(p);
            if (a == null) return;
            if (p.isInvisible() || p.isSpectator()) return;         // never reveal invisible players
            if (!gui) {
                boolean own = p == mc.player;
                if (own ? !EmotesConfig.SHOW_OWN.get() : !EmotesConfig.SHOW_OTHERS.get()) return;
                double d = ClientEmotes.distance;
                if (mc.gameRenderer.getMainCamera().getPosition().distanceToSqr(p.getX(), p.getEyeY(), p.getZ()) > d * d) return;
            }
            id = a.id(); t = a.seconds(); dur = a.durationMs() / 1000f;
        }
        EmoteDefs.Def def = EmoteDefs.get(id);
        if (def == null) return;

        boolean reduced = EmotesConfig.REDUCED_MOTION.get();
        boolean low = !preview && ClientEmotes.lowDetail;
        float user = preview ? 1f : EmotesConfig.SIZE.get().k;
        boolean helmet = !p.getItemBySlot(EquipmentSlot.HEAD).isEmpty();
        float lift = 0;
        if (!gui && p != mc.getCameraEntity() && EmotesConfig.LIFT_ABOVE_NAMETAG.get() && Minecraft.renderNames()
                && "above".equals(def.placement) && !p.isDiscrete()) lift = 6.5f;

        ps.pushPose();
        getParentModel().head.translateAndRotate(ps);
        Matrix4f m = ps.last().pose();
        float s = (float) Math.sqrt(m.m00() * m.m00() + m.m01() * m.m01() + m.m02() * m.m02());
        float up = gui ? -1f : 1f;
        int order = 0;
        for (int li = 0; li < def.layers.length; li++) {
            EmoteDefs.Layer l = def.layers[li];
            if (low && l.secondary) continue;
            VertexConsumer vc = buf.getBuffer(RenderType.text(l.tex));
            for (int ii = 0; ii < l.inst.length; ii++) {
                EmoteAnimator.eval(def, li, ii, t, dur, reduced, Q);
                order++;
                if (!Q.visible) continue;
                int alpha = (int) (Q.alpha * 255);
                float v0 = Q.frame / (float) l.frames, v1 = (Q.frame + 1) / (float) l.frames;
                float u0 = Q.flip ? 1 : 0, u1 = Q.flip ? 0 : 1;
                float rad = (float) Math.toRadians(Q.rot), cos = (float) Math.cos(rad), sin = (float) Math.sin(rad);
                if (l.face) {
                    float zf = Q.z + def.oz + (helmet ? 1.1f : 0f) + order * 0.012f;
                    float cx = (Q.x + def.ox) / 16f, cy = (-(Q.y + def.oy) - 4f) / 16f, cz = -zf / 16f;
                    float hw = Q.w * def.scale / 32f, hh = Q.h * def.scale / 32f;
                    // viewer-right R=(cos,-sin), viewer-up U=(-sin,-cos) in model space (model y points down)
                    float rx = cos * hw, ry = -sin * hw, ux = -sin * hh, uy = -cos * hh;
                    quadM(vc, m, cx, cy, cz, rx, ry, ux, uy, u0, u1, v0, v1, alpha);
                } else {
                    float bx = (Q.x * user + def.ox), by = (Q.y * user + def.oy + lift), bz = (Q.z * user + def.oz);
                    V.set(bx / 16f, (-by - 4f) / 16f, -bz / 16f, 1f);
                    m.transform(V);
                    float cz = V.z + order * 0.0015f * s;
                    float hw = Q.w * def.scale * user * s / 32f, hh = Q.h * def.scale * user * s / 32f;
                    float rx = cos * hw, ry = sin * hw * up, ux = -sin * hh, uy = cos * hh * up;
                    quad(vc, V.x, V.y, cz, rx, ry, ux, uy, u0, u1, v0, v1, alpha);
                }
            }
        }
        ps.popPose();
    }

    private static void quadM(VertexConsumer vc, Matrix4f m, float cx, float cy, float cz, float rx, float ry, float ux, float uy,
                              float u0, float u1, float v0, float v1, int a) {
        int L = LightTexture.FULL_BRIGHT;
        vc.vertex(m, cx - rx - ux, cy - ry - uy, cz).color(255, 255, 255, a).uv(u0, v1).uv2(L).endVertex();
        vc.vertex(m, cx + rx - ux, cy + ry - uy, cz).color(255, 255, 255, a).uv(u1, v1).uv2(L).endVertex();
        vc.vertex(m, cx + rx + ux, cy + ry + uy, cz).color(255, 255, 255, a).uv(u1, v0).uv2(L).endVertex();
        vc.vertex(m, cx - rx + ux, cy - ry + uy, cz).color(255, 255, 255, a).uv(u0, v0).uv2(L).endVertex();
    }

    private static void quad(VertexConsumer vc, float cx, float cy, float cz, float rx, float ry, float ux, float uy,
                             float u0, float u1, float v0, float v1, int a) {
        int L = LightTexture.FULL_BRIGHT;
        vc.vertex(cx - rx - ux, cy - ry - uy, cz).color(255, 255, 255, a).uv(u0, v1).uv2(L).endVertex();
        vc.vertex(cx + rx - ux, cy + ry - uy, cz).color(255, 255, 255, a).uv(u1, v1).uv2(L).endVertex();
        vc.vertex(cx + rx + ux, cy + ry + uy, cz).color(255, 255, 255, a).uv(u1, v0).uv2(L).endVertex();
        vc.vertex(cx - rx + ux, cy - ry + uy, cz).color(255, 255, 255, a).uv(u0, v0).uv2(L).endVertex();
    }
}
