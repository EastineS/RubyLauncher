package su.rubycon.emotes.client.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.controls.KeyBindsScreen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.common.ForgeConfigSpec;
import su.rubycon.emotes.EmotesConfig;

public class EmoteSettingsScreen extends Screen {
    private final Screen parent;

    public EmoteSettingsScreen(Screen parent) { super(Component.literal("Настройки эмоций")); this.parent = parent; }

    @Override protected void init() {
        int x = width / 2 - 155, y = height / 6 + 4, w = 150, h = 20;
        int i = 0;
        toggle(x, y, w, h, i++, "Эмоции других", EmotesConfig.SHOW_OTHERS, "Показывать эмоции других игроков");
        toggle(x, y, w, h, i++, "Свои эмоции", EmotesConfig.SHOW_OWN, "Показывать свою эмоцию (вид от третьего лица)");
        toggle(x, y, w, h, i++, "Индикатор (1-е лицо)", EmotesConfig.SHOW_INDICATOR, "Значок и полоска времени рядом с хотбаром");
        addRenderableWidget(CycleButton.<EmotesConfig.Size>builder(s -> Component.literal(s.label))
                .withValues(EmotesConfig.Size.values()).withInitialValue(EmotesConfig.SIZE.get())
                .withTooltip(s -> Tooltip.create(Component.literal("Размер эмоций над головами")))
                .create(pos(x, i, w), y + (i / 2) * 24, w, h, Component.literal("Размер"), (b, v) -> { EmotesConfig.SIZE.set(v); EmotesConfig.SIZE.save(); }));
        i++;
        toggle(x, y, w, h, i++, "Меньше движения", EmotesConfig.REDUCED_MOTION, "Без тряски и резких рывков");
        toggle(x, y, w, h, i++, "Кнопка в чате", EmotesConfig.CHAT_BUTTON, "Кнопка ☺ рядом с полем ввода чата");
        toggle(x, y, w, h, i++, "Выше ника", EmotesConfig.LIFT_ABOVE_NAMETAG, "Поднимать эмоции над головой выше ника");
        addRenderableWidget(Button.builder(Component.literal("Клавиши управления…"), b -> minecraft.setScreen(new KeyBindsScreen(this, minecraft.options)))
                .bounds(pos(x, i, w), y + (i / 2) * 24, w, h).build());
        i++;
        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose()).bounds(width / 2 - 100, y + ((i + 1) / 2) * 24 + 12, 200, 20).build());
    }

    private static int pos(int x, int i, int w) { return x + (i % 2) * (w + 10); }

    private void toggle(int x, int y, int w, int h, int i, String label, ForgeConfigSpec.BooleanValue v, String tip) {
        addRenderableWidget(CycleButton.onOffBuilder(v.get()).withTooltip(b -> Tooltip.create(Component.literal(tip)))
                .create(pos(x, i, w), y + (i / 2) * 24, w, h, Component.literal(label), (b, val) -> { v.set(val); v.save(); }));
    }

    @Override public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.drawCenteredString(font, title, width / 2, height / 6 - 14, 0xFFFFFF);
        g.drawCenteredString(font, Component.literal("Серверные правила (кулдаун, список, дистанция) задаёт администратор").withStyle(s -> s.withColor(0x9C93A3)),
                width / 2, height - 22, 0x9C93A3);
        super.render(g, mx, my, pt);
    }

    @Override public void onClose() { minecraft.setScreen(parent); }
}
