package su.rubycon.emotes.client;

/** Evaluates layer/instance transforms at time t (seconds). Mirrors the art pipeline's render.py exactly. */
public final class EmoteAnimator {
    public static final float INTRO = 0.3f, FADE_IN = 0.15f, OUTRO = 0.4f;

    public static final class Quad {
        public float x, y, z, w, h, rot, alpha; public int frame; public boolean flip, visible;
    }

    private static final float[] TMP = new float[3];

    public static void eval(EmoteDefs.Def def, int li, int ii, float t, float duration, boolean reduced, Quad q) {
        EmoteDefs.Layer l = def.layers[li];
        EmoteDefs.Inst in = l.inst[ii];
        q.visible = false;
        float lt = t - l.start - in.phase;
        if (lt < 0) return;
        if (l.loop > 0) lt = lt % l.loop;
        float dx = 0, dy = 0, dz = 0, sx = 1, sy = 1, r = 0, a = 1;
        if (sample(l.tPos, lt, l.smooth, 3, TMP)) { dx = TMP[0]; dy = TMP[1]; dz = TMP[2]; }
        if (sample(l.tScale, lt, l.smooth, 2, TMP)) { sx = TMP[0]; sy = TMP[1]; }
        if (sample(l.tRot, lt, l.smooth, 1, TMP)) r = TMP[0];
        if (sample(l.tAlpha, lt, l.smooth, 1, TMP)) a = TMP[0];
        if (l.intense && reduced) { sx = 1 + (sx - 1) * 0.3f; sy = 1 + (sy - 1) * 0.3f; r *= 0.3f; a = 1 + (a - 1) * 0.3f; }
        float x = l.px + in.ox + dx, y = l.py + in.oy + dy, z = l.pz + in.oz + dz;
        if (l.shakeAmp > 0 && !reduced) {
            float seed = li * 1.7f + ii * 3.1f;
            x += l.shakeAmp * (float) Math.sin(2 * Math.PI * l.shakeHz * t + seed);
            y += l.shakeAmp * (float) Math.sin(2 * Math.PI * l.shakeHz * 1.37 * t + seed * 2.1);
        }
        float env = 1;
        if (l.pop) {
            if (t < INTRO) env = backOut(t / INTRO);
            a *= Math.min(1f, t / FADE_IN);
        }
        float rem = duration - t;
        if (rem < OUTRO) { float k = Math.max(0, rem / OUTRO); a *= k; env *= 0.85f + 0.15f * k; }
        float rot = r + in.rot;
        if (in.flip) { x = -x; rot = -rot; }
        int fr = 0;
        if (l.frames > 1) {
            if (l.tFrame != null) fr = Math.floorMod(step(l.tFrame, lt), l.frames);
            else if (l.fps > 0) fr = Math.floorMod((int) (lt * l.fps), l.frames);
        }
        q.x = x; q.y = y; q.z = z;
        q.w = l.w * sx * in.scale * env; q.h = l.h * sy * in.scale * env;
        q.rot = rot; q.alpha = Math.max(0, Math.min(1, a)); q.flip = in.flip; q.frame = fr;
        q.visible = q.alpha > 0.02f && q.w > 0.01f && q.h > 0.01f;
    }

    static float backOut(float x) { float c1 = 1.70158f, c3 = c1 + 1; x -= 1; return 1 + c3 * x * x * x + c1 * x * x; }

    private static void pad(float[] key, int n, float[] out) {
        int have = key.length - 1;
        if (n == 2 && have == 1) { out[0] = key[1]; out[1] = key[1]; return; }
        for (int i = 0; i < n; i++) out[i] = i < have ? key[i + 1] : 0;
    }

    private static final float[] A = new float[3], Bv = new float[3];
    static boolean sample(float[][] keys, float t, boolean smooth, int n, float[] out) {
        if (keys == null) return false;
        if (t <= keys[0][0]) { pad(keys[0], n, out); return true; }
        for (int i = 0; i < keys.length - 1; i++) {
            float[] a = keys[i], b = keys[i + 1];
            if (t <= b[0]) {
                float f = (t - a[0]) / Math.max(1e-6f, b[0] - a[0]);
                if (smooth) f = f * f * (3 - 2 * f);
                pad(a, n, A); pad(b, n, Bv);
                for (int c = 0; c < n; c++) out[c] = A[c] + (Bv[c] - A[c]) * f;
                return true;
            }
        }
        pad(keys[keys.length - 1], n, out);
        return true;
    }
    static int step(float[][] keys, float t) {
        float v = keys[0][1];
        for (float[] k : keys) if (t >= k[0]) v = k[1];
        return (int) v;
    }
}
