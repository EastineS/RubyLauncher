package su.rubycon.emotes.client;

import com.google.gson.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import su.rubycon.emotes.RubyconEmotes;

import java.io.Reader;
import java.util.*;

/** Visual definitions of emotes: assets/<ns>/emotes/<id>.json (overridable by resource packs). */
public final class EmoteDefs extends SimplePreparableReloadListener<Map<String, EmoteDefs.Def>> {
    public static final class Inst { public float ox, oy, oz, phase, scale = 1, rot; public boolean flip; }
    public static final class Layer {
        public ResourceLocation tex; public int frames = 1; public float fps;
        public float w, h, px, py, pz; public boolean face, smooth, secondary, intense, pop = true;
        public float loop, start;
        public float[][] tPos, tScale, tRot, tAlpha, tFrame;
        public float shakeAmp, shakeHz;
        public Inst[] inst;
    }
    public static final class Def {
        public String id, name, description = "", placement = "side";
        public float duration = 4, scale = 1, ox, oy, oz;
        public ResourceLocation icon;
        public Layer[] layers;
    }

    private static Map<String, Def> DEFS = Map.of();
    public static Def get(String id) { return DEFS.get(id); }

    @Override
    protected Map<String, Def> prepare(ResourceManager rm, ProfilerFiller p) {
        Map<String, Def> out = new HashMap<>();
        for (Map.Entry<ResourceLocation, Resource> en : rm.listResources("emotes", rl -> rl.getPath().endsWith(".json")).entrySet()) {
            try (Reader r = en.getValue().openAsReader()) {
                Def d = parse(JsonParser.parseReader(r).getAsJsonObject(), rm);
                out.put(d.id, d);
            } catch (Exception ex) {
                RubyconEmotes.LOG.error("Broken emote definition {}: {}", en.getKey(), ex.toString());
            }
        }
        return out;
    }

    @Override
    protected void apply(Map<String, Def> m, ResourceManager rm, ProfilerFiller p) {
        DEFS = m;
        RubyconEmotes.LOG.info("Loaded {} emote definitions", m.size());
    }

    private static Def parse(JsonObject o, ResourceManager rm) {
        Def d = new Def();
        d.id = o.get("id").getAsString();
        d.name = str(o, "name", d.id);
        d.description = str(o, "description", "");
        d.placement = str(o, "placement", "side");
        d.duration = f(o, "duration", 4);
        d.scale = f(o, "scale", 1);
        float[] off = vec(o.get("offset"), 3);
        d.ox = off[0]; d.oy = off[1]; d.oz = off[2];
        ResourceLocation icon = new ResourceLocation(str(o, "icon", RubyconEmotes.MODID + ":textures/emote/icon/" + d.id + ".png"));
        d.icon = rm.getResource(icon).isPresent() ? icon : null;
        List<Layer> layers = new ArrayList<>();
        for (JsonElement el : o.getAsJsonArray("layers")) {
            JsonObject j = el.getAsJsonObject();
            Layer l = new Layer();
            l.tex = new ResourceLocation(j.get("texture").getAsString());
            if (rm.getResource(l.tex).isEmpty()) {           // missing texture: skip the layer instead of drawing the purple checkerboard
                RubyconEmotes.LOG.warn("Emote {}: missing texture {}, layer skipped", d.id, l.tex);
                continue;
            }
            float[] size = vec(j.get("size"), 2), pos = vec(j.get("pos"), 3);
            l.w = size[0]; l.h = size[1]; l.px = pos[0]; l.py = pos[1]; l.pz = pos[2];
            l.face = "face".equals(str(j, "space", "billboard"));
            l.frames = Math.max(1, (int) f(j, "frames", 1));
            l.fps = f(j, "fps", 0);
            l.loop = f(j, "loop", 0);
            l.start = f(j, "start", 0);
            l.smooth = "smooth".equals(str(j, "ease", "linear"));
            l.secondary = b(j, "secondary", false);
            l.intense = b(j, "intense", false);
            l.pop = b(j, "pop", true);
            if (j.has("shake")) { float[] s = vec(j.get("shake"), 2); l.shakeAmp = s[0]; l.shakeHz = s[1]; }
            JsonObject tr = j.has("tracks") ? j.getAsJsonObject("tracks") : new JsonObject();
            l.tPos = keys(tr, "pos"); l.tScale = keys(tr, "scale"); l.tRot = keys(tr, "rot"); l.tAlpha = keys(tr, "alpha"); l.tFrame = keys(tr, "frame");
            List<Inst> insts = new ArrayList<>();
            if (j.has("instances")) for (JsonElement ie : j.getAsJsonArray("instances")) {
                JsonObject io = ie.getAsJsonObject(); Inst in = new Inst();
                float[] ofs = vec(io.get("offset"), 3); in.ox = ofs[0]; in.oy = ofs[1]; in.oz = ofs[2];
                in.phase = f(io, "phase", 0); in.flip = b(io, "flip", false); in.scale = f(io, "scale", 1); in.rot = f(io, "rot", 0);
                insts.add(in);
            }
            if (insts.isEmpty()) insts.add(new Inst());
            l.inst = insts.toArray(new Inst[0]);
            layers.add(l);
        }
        d.layers = layers.toArray(new Layer[0]);
        return d;
    }

    private static float[][] keys(JsonObject tr, String k) {
        if (!tr.has(k)) return null;
        JsonArray a = tr.getAsJsonArray(k);
        float[][] out = new float[a.size()][];
        for (int i = 0; i < a.size(); i++) {
            JsonArray row = a.get(i).getAsJsonArray();
            out[i] = new float[row.size()];
            for (int c = 0; c < row.size(); c++) out[i][c] = row.get(c).getAsFloat();
        }
        Arrays.sort(out, Comparator.comparingDouble(r -> r[0]));
        return out.length == 0 ? null : out;
    }
    private static float[] vec(JsonElement e, int n) {
        float[] v = new float[n];
        if (e != null && e.isJsonArray()) { JsonArray a = e.getAsJsonArray(); for (int i = 0; i < Math.min(n, a.size()); i++) v[i] = a.get(i).getAsFloat(); }
        return v;
    }
    private static String str(JsonObject o, String k, String d) { return o.has(k) ? o.get(k).getAsString() : d; }
    private static float f(JsonObject o, String k, float d) { return o.has(k) ? o.get(k).getAsFloat() : d; }
    private static boolean b(JsonObject o, String k, boolean d) { return o.has(k) ? o.get(k).getAsBoolean() : d; }
}
