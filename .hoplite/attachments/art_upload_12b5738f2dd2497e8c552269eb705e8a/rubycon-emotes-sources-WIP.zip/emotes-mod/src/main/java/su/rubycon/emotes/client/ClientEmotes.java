package su.rubycon.emotes.client;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import su.rubycon.emotes.EmoteIndex;
import su.rubycon.emotes.EmotesConfig;
import su.rubycon.emotes.net.EmoteNetwork;

import java.util.*;

/** Client-side emote state: active emotes of players, server rules, preview override. */
public final class ClientEmotes {
    public record Active(String id, long startNanos, int durationMs) {
        public float seconds() { return (System.nanoTime() - startNanos) / 1e9f; }
        public boolean expired() { return seconds() * 1000 > durationMs; }
    }
    private static final Map<Integer, Active> ACTIVE = new HashMap<>();

    // server rules (defaults used until Sync arrives)
    public static boolean serverSupported, serverEnabled = true;
    public static int cooldownMs = 2000, distance = 24;
    private static List<EmoteNetwork.Entry> entries = null;
    private static long lastRequest;
    public static boolean lowDetail;

    // preview override (GUI)
    public static int previewEntity = Integer.MIN_VALUE;
    public static String previewId;
    public static long previewStart;
    public static int previewDuration;

    public static void onState(EmoteNetwork.State s) {
        if (s.id().isEmpty()) { ACTIVE.remove(s.entityId()); return; }
        ACTIVE.put(s.entityId(), new Active(s.id(), System.nanoTime() - s.elapsedMs() * 1_000_000L, s.durationMs()));
    }

    public static void onSync(EmoteNetwork.Sync s) {
        serverSupported = true;
        serverEnabled = s.enabled(); cooldownMs = s.cooldownMs(); distance = s.distance(); entries = s.entries();
    }

    public static void reset() {
        ACTIVE.clear(); serverSupported = false; serverEnabled = true; entries = null; cooldownMs = 2000; distance = 24;
    }

    /** Emotes offered in the menu: the server list if known, otherwise the built-in index. */
    public static List<EmoteNetwork.Entry> entries() {
        if (entries != null) return entries;
        List<EmoteNetwork.Entry> l = new ArrayList<>();
        for (EmoteIndex.Info i : EmoteIndex.all()) l.add(new EmoteNetwork.Entry(i.id(), i.name(), i.durationMs(), true));
        return l;
    }
    public static EmoteNetwork.Entry entry(String id) {
        for (EmoteNetwork.Entry e : entries()) if (e.id().equals(id)) return e;
        return null;
    }

    public static Active active(Entity e) {
        Active a = ACTIVE.get(e.getId());
        if (a != null && a.expired()) { ACTIVE.remove(e.getId()); return null; }
        return a;
    }
    public static Active own() { Player p = Minecraft.getInstance().player; return p == null ? null : active(p); }

    public static float cooldownLeft() {
        return Math.max(0, (cooldownMs - (System.currentTimeMillis() - lastRequest)) / 1000f);
    }

    public static boolean request(String id) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return false;
        if (!EmoteNetwork.CH.isRemotePresent(mc.getConnection().getConnection())) { msg("На этом сервере нет модуля эмоций"); return false; }
        if (!serverEnabled) { msg("Эмоции отключены на сервере"); return false; }
        EmoteNetwork.Entry e = entry(id);
        if (e == null || !e.allowed()) { msg("Эта эмоция недоступна на сервере"); return false; }
        float left = cooldownLeft();
        if (left > 0) { msg(String.format(Locale.ROOT, "Подождите %.1f с", left)); return false; }
        lastRequest = System.currentTimeMillis();
        EmoteNetwork.CH.sendToServer(new EmoteNetwork.Play(id));
        return true;
    }

    public static void cancel() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || own() == null) return;
        if (EmoteNetwork.CH.isRemotePresent(mc.getConnection().getConnection())) EmoteNetwork.CH.sendToServer(new EmoteNetwork.Play(""));
    }

    static void msg(String s) {
        Player p = Minecraft.getInstance().player;
        if (p != null) p.displayClientMessage(Component.literal(s).withStyle(ChatFormatting.GOLD), true);
    }

    /** Called every client tick: expire finished emotes, drop removed entities, decide detail level. */
    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) { if (!ACTIVE.isEmpty()) ACTIVE.clear(); return; }
        int near = 0; double d2 = (double) distance * distance;
        Iterator<Map.Entry<Integer, Active>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Active> en = it.next();
            Entity e = mc.level.getEntity(en.getKey());
            if (en.getValue().expired() || e == null || !e.isAlive()) { it.remove(); continue; }
            if (mc.player != null && e.distanceToSqr(mc.player) < d2) near++;
        }
        lowDetail = near > 16;
    }

    public static boolean favorite(String id) { return EmotesConfig.FAVORITES.get().contains(id); }
    public static List<String> favorites() { return new ArrayList<>(EmotesConfig.FAVORITES.get()); }
    public static boolean toggleFavorite(String id) {
        List<String> f = favorites();
        if (f.contains(id)) f.remove(id);
        else { if (f.size() >= 8) { msg("В избранном не больше 8 эмоций"); return false; } f.add(id); }
        EmotesConfig.FAVORITES.set(f); EmotesConfig.FAVORITES.save();
        return true;
    }
}
