package su.rubycon.emotes.server;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.server.ServerLifecycleHooks;
import su.rubycon.emotes.EmoteIndex;
import su.rubycon.emotes.EmotesConfig;
import su.rubycon.emotes.net.EmoteNetwork;

import java.util.*;

public final class EmoteServer {
    private record Active(String id, long start, int duration) {}
    private static final Map<UUID, Active> ACTIVE = new HashMap<>();
    private static final Map<UUID, Long> LAST = new HashMap<>();

    public static boolean allowed(String id) {
        List<? extends String> a = EmotesConfig.ALLOWED.get();
        return EmoteIndex.get(id) != null && (a.isEmpty() || a.contains(id));
    }

    private static String blockedReason(ServerPlayer sp) {
        if (!EmotesConfig.ENABLED.get()) return "Эмоции отключены на сервере";
        if (sp.isSpectator() && EmotesConfig.DISABLED_GAMEMODES.get().contains("spectator")) return "Эмоции недоступны в режиме наблюдателя";
        GameType gt = sp.gameMode.getGameModeForPlayer();
        if (EmotesConfig.DISABLED_GAMEMODES.get().contains(gt.getName())) return "Эмоции недоступны в этом режиме игры";
        if (EmotesConfig.DISABLED_DIMENSIONS.get().contains(sp.level().dimension().location().toString())) return "Эмоции недоступны в этом мире";
        return null;
    }

    public static void play(ServerPlayer sp, String id) {
        String reason = blockedReason(sp);
        if (reason != null) { feedback(sp, reason); return; }
        EmoteIndex.Info info = EmoteIndex.get(id);
        if (info == null || !allowed(id)) { feedback(sp, "Эта эмоция недоступна"); return; }
        long now = System.currentTimeMillis();
        Long last = LAST.get(sp.getUUID());
        int cd = EmotesConfig.COOLDOWN_MS.get();
        if (last != null && now - last < cd) {
            feedback(sp, String.format(Locale.ROOT, "Подождите %.1f с", (cd - (now - last)) / 1000f));
            return;
        }
        LAST.put(sp.getUUID(), now);
        int dur = (int) Math.min(info.durationMs(), Math.round(EmotesConfig.MAX_DURATION.get() * 1000));
        ACTIVE.put(sp.getUUID(), new Active(id, now, dur));
        EmoteNetwork.CH.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> sp), new EmoteNetwork.State(sp.getId(), id, 0, dur));
    }

    public static void stop(ServerPlayer sp, boolean broadcast) {
        if (ACTIVE.remove(sp.getUUID()) != null && broadcast)
            EmoteNetwork.CH.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> sp), new EmoteNetwork.State(sp.getId(), "", 0, 0));
    }

    private static void feedback(ServerPlayer sp, String msg) {
        sp.displayClientMessage(Component.literal(msg).withStyle(ChatFormatting.GOLD), true);
    }

    public static EmoteNetwork.Sync syncPacket() {
        List<EmoteNetwork.Entry> l = new ArrayList<>();
        int max = (int) Math.round(EmotesConfig.MAX_DURATION.get() * 1000);
        for (EmoteIndex.Info i : EmoteIndex.all()) l.add(new EmoteNetwork.Entry(i.id(), i.name(), Math.min(i.durationMs(), max), allowed(i.id())));
        return new EmoteNetwork.Sync(EmotesConfig.ENABLED.get(), EmotesConfig.COOLDOWN_MS.get(), EmotesConfig.DISTANCE.get(), l);
    }

    private static void sendSync(ServerPlayer sp) {
        if (EmoteNetwork.CH.isRemotePresent(sp.connection.connection)) EmoteNetwork.CH.send(PacketDistributor.PLAYER.with(() -> sp), syncPacket());
    }

    // ---------------------------------------------------------------- events
    @SubscribeEvent public static void onStarting(ServerStartingEvent e) { EmoteIndex.reload(); ACTIVE.clear(); LAST.clear(); }

    public static void onConfigReload(ModConfigEvent.Reloading e) {
        if (e.getConfig().getSpec() != EmotesConfig.SERVER_SPEC) return;
        MinecraftServer s = ServerLifecycleHooks.getCurrentServer();
        if (s != null) s.execute(() -> s.getPlayerList().getPlayers().forEach(EmoteServer::sendSync));
    }

    @SubscribeEvent public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) { if (e.getEntity() instanceof ServerPlayer sp) sendSync(sp); }

    @SubscribeEvent public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) { stop(sp, true); LAST.remove(sp.getUUID()); }
    }
    @SubscribeEvent public static void onDeath(LivingDeathEvent e) { if (e.getEntity() instanceof ServerPlayer sp) stop(sp, true); }
    @SubscribeEvent public static void onDim(PlayerEvent.PlayerChangedDimensionEvent e) { if (e.getEntity() instanceof ServerPlayer sp) stop(sp, true); }
    @SubscribeEvent public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) { if (e.getEntity() instanceof ServerPlayer sp) stop(sp, true); }
    @SubscribeEvent public static void onGameMode(PlayerEvent.PlayerChangeGameModeEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp && EmotesConfig.DISABLED_GAMEMODES.get().contains(e.getNewGameMode().getName())) stop(sp, true);
    }

    /** A player that starts seeing another one receives the rest of the running emote. */
    @SubscribeEvent public static void onTrack(PlayerEvent.StartTracking e) {
        if (!(e.getTarget() instanceof ServerPlayer target) || !(e.getEntity() instanceof ServerPlayer viewer)) return;
        Active a = ACTIVE.get(target.getUUID());
        if (a == null) return;
        int elapsed = (int) (System.currentTimeMillis() - a.start);
        if (elapsed >= a.duration) return;
        if (EmoteNetwork.CH.isRemotePresent(viewer.connection.connection))
            EmoteNetwork.CH.send(PacketDistributor.PLAYER.with(() -> viewer), new EmoteNetwork.State(target.getId(), a.id, elapsed, a.duration));
    }

    private static int tick;
    @SubscribeEvent public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || ++tick % 20 != 0) return;
        long now = System.currentTimeMillis();
        ACTIVE.values().removeIf(a -> now - a.start > a.duration);
        LAST.values().removeIf(t -> now - t > 120_000);
    }

    @SubscribeEvent public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("emote")
                .then(Commands.literal("stop").executes(c -> { stop(c.getSource().getPlayerOrException(), true); return 1; }))
                .then(Commands.literal("list").executes(c -> {
                    StringBuilder sb = new StringBuilder("Эмоции: ");
                    for (EmoteIndex.Info i : EmoteIndex.all()) if (allowed(i.id())) sb.append(i.id()).append(" (").append(i.name()).append("), ");
                    c.getSource().sendSuccess(() -> Component.literal(sb.substring(0, Math.max(0, sb.length() - 2))), false);
                    return 1; }))
                .then(Commands.argument("id", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(EmoteIndex.all().stream().map(EmoteIndex.Info::id).filter(EmoteServer::allowed), b))
                        .executes(c -> { play(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "id")); return 1; })));
    }
}
