package su.rubycon.emotes;

import net.minecraftforge.common.ForgeConfigSpec;
import java.util.List;

public final class EmotesConfig {
    // ---------------- server (synced to clients by Forge) ----------------
    public static final ForgeConfigSpec SERVER_SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> ALLOWED;
    public static final ForgeConfigSpec.IntValue COOLDOWN_MS;
    public static final ForgeConfigSpec.DoubleValue MAX_DURATION;
    public static final ForgeConfigSpec.IntValue DISTANCE;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> DISABLED_DIMENSIONS;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> DISABLED_GAMEMODES;

    // ---------------- client ----------------
    public enum Size { SMALL(0.75f, "Маленький"), NORMAL(1f, "Обычный"), LARGE(1.3f, "Крупный");
        public final float k; public final String label; Size(float k, String l) { this.k = k; this.label = l; } }
    public static final ForgeConfigSpec CLIENT_SPEC;
    public static final ForgeConfigSpec.BooleanValue SHOW_OTHERS, SHOW_OWN, SHOW_INDICATOR, REDUCED_MOTION, CHAT_BUTTON, LIFT_ABOVE_NAMETAG;
    public static final ForgeConfigSpec.EnumValue<Size> SIZE;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> FAVORITES;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("Эмоции персонажа — серверные настройки").push("emotes");
        ENABLED = b.comment("Включить систему эмоций").define("enabled", true);
        ALLOWED = b.comment("Разрешённые эмоции (id). Пустой список — разрешены все из индекса")
                .defineListAllowEmpty(List.of("allowed"), List::of, o -> o instanceof String);
        COOLDOWN_MS = b.comment("Минимальный интервал между активациями, мс").defineInRange("cooldownMs", 2000, 0, 60000);
        MAX_DURATION = b.comment("Максимальная длительность эмоции, сек").defineInRange("maxDuration", 6.0, 1.0, 30.0);
        DISTANCE = b.comment("Дистанция отображения, блоков").defineInRange("displayDistance", 24, 4, 128);
        DISABLED_DIMENSIONS = b.comment("Миры, где эмоции запрещены (например minecraft:the_end)")
                .defineListAllowEmpty(List.of("disabledDimensions"), List::of, o -> o instanceof String);
        DISABLED_GAMEMODES = b.comment("Режимы игры, где эмоции запрещены: survival, creative, adventure, spectator")
                .defineListAllowEmpty(List.of("disabledGameModes"), () -> List.of("spectator"), o -> o instanceof String);
        b.pop();
        SERVER_SPEC = b.build();

        ForgeConfigSpec.Builder c = new ForgeConfigSpec.Builder();
        c.comment("Эмоции персонажа — настройки игрока").push("emotes");
        SHOW_OTHERS = c.comment("Показывать эмоции других игроков").define("showOthers", true);
        SHOW_OWN = c.comment("Показывать собственную эмоцию в третьем лице").define("showOwnThirdPerson", true);
        SHOW_INDICATOR = c.comment("Показывать индикатор собственной эмоции в первом лице").define("firstPersonIndicator", true);
        SIZE = c.comment("Масштаб эффектов").defineEnum("size", Size.NORMAL);
        REDUCED_MOTION = c.comment("Уменьшенная анимация: без резкого дрожания и частых вспышек").define("reducedMotion", false);
        CHAT_BUTTON = c.comment("Кнопка эмоций рядом с полем ввода чата").define("chatButton", true);
        LIFT_ABOVE_NAMETAG = c.comment("Поднимать эффекты над головой выше ника").define("liftAboveNametag", true);
        FAVORITES = c.comment("Избранные эмоции (до 8) — колесо быстрого выбора")
                .defineListAllowEmpty(List.of("favorites"),
                        () -> List.of("anger", "laugh", "love", "awkward", "confused", "facepalm", "surprise", "smug"),
                        o -> o instanceof String);
        c.pop();
        CLIENT_SPEC = c.build();
    }
}
