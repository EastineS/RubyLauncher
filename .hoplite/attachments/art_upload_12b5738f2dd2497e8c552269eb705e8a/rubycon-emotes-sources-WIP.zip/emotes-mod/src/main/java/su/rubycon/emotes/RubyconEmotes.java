package su.rubycon.emotes;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.eventbus.api.IEventBus;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;
import su.rubycon.emotes.net.EmoteNetwork;
import su.rubycon.emotes.server.EmoteServer;

@Mod(RubyconEmotes.MODID)
public final class RubyconEmotes {
    public static final String MODID = "rubycon_emotes";
    public static final Logger LOG = LogUtils.getLogger();

    public RubyconEmotes() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, EmotesConfig.SERVER_SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, EmotesConfig.CLIENT_SPEC);
        EmoteNetwork.register();
        EmoteIndex.reload();
        MinecraftForge.EVENT_BUS.register(EmoteServer.class);
        modBus.addListener(EmoteServer::onConfigReload);
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> su.rubycon.emotes.client.ClientSetup.init(modBus));
    }
}
