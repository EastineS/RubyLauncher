package su.rubycon.emotes.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import su.rubycon.emotes.EmotesConfig;
import su.rubycon.emotes.client.ClientEmotes;

/** First-person indicator: small icon + remaining-time bar to the right of the hotbar. */
public final class EmoteHud {
    public static void render(ForgeGui gui, GuiGraphics g, float partial, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || !EmotesConfig.SHOW_INDICATOR.get()) return;
        if (!mc.options.getCameraType().isFirstPerson()) return;
        ClientEmotes.Active a = ClientEmotes.own();
        if (a == null) return;
        float t = a.seconds(), d = a.durationMs() / 1000f;
        float left = Math.max(0, 1 - t / d);
        float pop = Math.min(1, t / 0.2f), fade = Math.min(1, (d - t) / 0.3f);
        float alpha = Math.max(0.05f, Math.min(pop, fade));
        int x = w / 2 + 98, y = h - 22;
        if (mc.player.getOffhandItem().isEmpty() == false && mc.options.mainHand().get() == net.minecraft.world.entity.HumanoidArm.LEFT) x += 29;
        int a8 = (int) (alpha * 0xF0) << 24;
        g.fill(x, y, x + 22, y + 22, a8 | 0x141118);
        Ui.icon(g, a.id(), x + 1, y + 1, 20, alpha);
        g.fill(x + 1, y + 20, x + 21, y + 22, a8 | 0x2A2330);
        g.fill(x + 1, y + 20, x + 1 + Math.round(20 * left), y + 22, ((int) (alpha * 255) << 24) | 0xD6334F);
    }
}
