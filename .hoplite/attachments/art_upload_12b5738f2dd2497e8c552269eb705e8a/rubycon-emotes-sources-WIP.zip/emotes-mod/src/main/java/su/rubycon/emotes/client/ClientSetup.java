package su.rubycon.emotes.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraftforge.client.ConfigScreenHandler;
import net.minecraftforge.client.event.*;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import org.lwjgl.glfw.GLFW;
import su.rubycon.emotes.client.gui.*;

public final class ClientSetup {
    public static final String CATEGORY = "key.categories.rubycon_emotes";
    public static final KeyMapping MENU = new KeyMapping("key.rubycon_emotes.menu", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, CATEGORY);
    public static final KeyMapping WHEEL = new KeyMapping("key.rubycon_emotes.wheel", KeyConflictContext.IN_GAME,
            InputConstants.UNKNOWN, CATEGORY);
    public static final KeyMapping CANCEL = new KeyMapping("key.rubycon_emotes.cancel", KeyConflictContext.IN_GAME,
            InputConstants.UNKNOWN, CATEGORY);
    private static final long HOLD_MS = 250;

    private static boolean wasDown, wheelFromHold, ignoreUntilRelease;
    private static long pressStart;

    public static void init(IEventBus modBus) {
        modBus.addListener((RegisterKeyMappingsEvent e) -> { e.register(MENU); e.register(WHEEL); e.register(CANCEL); });
        modBus.addListener((EntityRenderersEvent.AddLayers e) -> {
            for (String s : e.getSkins()) {
                PlayerRenderer r = e.getSkin(s);
                if (r != null) r.addLayer(new EmoteLayer(r));
            }
        });
        modBus.addListener((RegisterClientReloadListenersEvent e) -> e.registerReloadListener(new EmoteDefs()));
        modBus.addListener((RegisterGuiOverlaysEvent e) -> e.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "emote_indicator", EmoteHud::render));
        ModLoadingContext.get().registerExtensionPoint(ConfigScreenHandler.ConfigScreenFactory.class,
                () -> new ConfigScreenHandler.ConfigScreenFactory((mc, parent) -> new EmoteSettingsScreen(parent)));
        MinecraftForge.EVENT_BUS.addListener(ClientSetup::onTick);
        MinecraftForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingOut e) -> ClientEmotes.reset());
        MinecraftForge.EVENT_BUS.register(ChatEmoteButton.class);
    }

    /** Raw key state (works while a screen is open, unlike KeyMapping#isDown). */
    public static boolean rawDown(KeyMapping k) {
        InputConstants.Key key = k.getKey();
        if (key == InputConstants.UNKNOWN) return false;
        long win = Minecraft.getInstance().getWindow().getWindow();
        if (key.getType() == InputConstants.Type.MOUSE) return GLFW.glfwGetMouseButton(win, key.getValue()) == GLFW.GLFW_PRESS;
        return InputConstants.isKeyDown(win, key.getValue());
    }

    private static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        ClientEmotes.tick();
        Minecraft mc = Minecraft.getInstance();
        boolean down = rawDown(MENU) && MENU.getKeyModifier().isActive(KeyConflictContext.IN_GAME);
        if (mc.player == null || mc.screen != null) {
            if (down) ignoreUntilRelease = true;
            wasDown = false; wheelFromHold = false;
            return;
        }
        if (ignoreUntilRelease) { if (!down) ignoreUntilRelease = false; return; }
        long now = System.currentTimeMillis();
        if (down && !wasDown) { pressStart = now; wheelFromHold = false; }
        if (down && !wheelFromHold && now - pressStart >= HOLD_MS) {
            wheelFromHold = true;
            mc.setScreen(new EmoteWheelScreen(MENU));
        }
        if (!down && wasDown && !wheelFromHold) mc.setScreen(new EmoteMenuScreen());
        wasDown = down;
        while (MENU.consumeClick()) { /* handled via raw state above */ }
        if (WHEEL.consumeClick() && mc.screen == null) mc.setScreen(new EmoteWheelScreen(WHEEL));
        while (CANCEL.consumeClick()) ClientEmotes.cancel();
    }
}
