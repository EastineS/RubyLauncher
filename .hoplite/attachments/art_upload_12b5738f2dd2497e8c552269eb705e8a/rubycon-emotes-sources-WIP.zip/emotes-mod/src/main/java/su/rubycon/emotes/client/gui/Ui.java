package su.rubycon.emotes.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import su.rubycon.emotes.RubyconEmotes;
import su.rubycon.emotes.client.EmoteDefs;

import java.util.HashSet;
import java.util.Set;

/** Shared drawing helpers in the dark/ruby style of Rubycon UI. */
public final class Ui {
    public static final int BG = 0xF0141118, BG2 = 0xFF1E1922, CELL = 0xFF2A2330, CELL_HOVER = 0xFF3A3042,
            BORDER = 0xFF3D3344, ACCENT = 0xFFD6334F, ACCENT_SOFT = 0x66D6334F, TEXT = 0xFFF5F0EA, MUTED = 0xFF9C93A3,
            GOLD = 0xFFFFC94A;
    private static final Set<ResourceLocation> FILTERED = new HashSet<>();

    public static void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x + 1, y, x + w - 1, y + h, BG);
        g.fill(x, y + 1, x + w, y + h - 1, BG);
        g.fill(x + 1, y, x + w - 1, y + 1, BORDER);
        g.fill(x + 1, y + h - 1, x + w - 1, y + h, BORDER);
        g.fill(x, y + 1, x + 1, y + h - 1, BORDER);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, BORDER);
    }

    public static void box(GuiGraphics g, int x, int y, int w, int h, int fill, int border) {
        g.fill(x, y, x + w, y + h, fill);
        if (border != 0) {
            g.fill(x, y, x + w, y + 1, border); g.fill(x, y + h - 1, x + w, y + h, border);
            g.fill(x, y, x + 1, y + h, border); g.fill(x + w - 1, y, x + w, y + h, border);
        }
    }

    public static ResourceLocation icon(String id) {
        EmoteDefs.Def d = EmoteDefs.get(id);
        return d != null && d.icon != null ? d.icon : new ResourceLocation(RubyconEmotes.MODID, "textures/emote/icon/" + id + ".png");
    }

    /** Draws a 64px icon smoothly scaled to size. */
    public static void icon(GuiGraphics g, String id, int x, int y, int size, float alpha) {
        ResourceLocation rl = icon(id);
        if (FILTERED.add(rl)) Minecraft.getInstance().getTextureManager().getTexture(rl).setFilter(true, false);
        RenderSystem.enableBlend();
        g.setColor(1, 1, 1, alpha);
        g.blit(rl, x, y, size, size, 0, 0, 64, 64, 64, 64);
        g.setColor(1, 1, 1, 1);
    }

    public static void star(GuiGraphics g, Font f, int x, int y, boolean on) {
        g.drawString(f, "★", x, y, on ? GOLD : 0x80FFFFFF, true);
    }

    public static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && my >= y && mx < x + w && my < y + h;
    }

    public static void button(GuiGraphics g, Font f, int x, int y, int w, int h, Component text, boolean hover, boolean active, boolean accent) {
        int fill = !active ? 0xFF221D26 : accent ? (hover ? 0xFFE84661 : ACCENT) : (hover ? CELL_HOVER : CELL);
        box(g, x, y, w, h, fill, active && hover ? 0x50FFFFFF : 0);
        g.drawCenteredString(f, text, x + w / 2, y + (h - 8) / 2, active ? TEXT : MUTED);
    }
}
