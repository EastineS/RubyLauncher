package su.rubycon.emotes.client.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import org.lwjgl.glfw.GLFW;
import su.rubycon.emotes.client.ClientEmotes;
import su.rubycon.emotes.client.ClientSetup;
import su.rubycon.emotes.client.EmoteDefs;
import su.rubycon.emotes.net.EmoteNetwork;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Main emote menu (G): grid, favourites tab, description, live 3D preview. */
public class EmoteMenuScreen extends Screen {
    private static final int W = 310, H = 192, CELL = 26, COLS = 5;
    private static boolean favTab;
    private static String selected;
    private static boolean helmet;
    private final EmotePreview preview = new EmotePreview();
    private int x0, y0;
    private long lastClick; private String lastClickId;
    private boolean dragging;

    public EmoteMenuScreen() { super(Component.literal("Эмоции персонажа")); }

    @Override protected void init() {
        x0 = (width - W) / 2; y0 = (height - H) / 2;
        List<String> l = list();
        if (selected == null || EmoteDefs.get(selected) == null) selected = l.isEmpty() ? null : l.get(0);
    }

    private List<String> list() {
        List<String> out = new ArrayList<>();
        if (favTab) { for (String f : ClientEmotes.favorites()) if (ClientEmotes.entry(f) != null) out.add(f); }
        else for (EmoteNetwork.Entry e : ClientEmotes.entries()) out.add(e.id());
        return out;
    }

    static String name(String id) {
        EmoteNetwork.Entry e = ClientEmotes.entry(id);
        if (e != null && !e.name().isEmpty()) return e.name();
        EmoteDefs.Def d = EmoteDefs.get(id);
        return d != null ? d.name : id;
    }

    static boolean allowed(String id) {
        EmoteNetwork.Entry e = ClientEmotes.entry(id);
        return e != null && e.allowed() && ClientEmotes.serverEnabled;
    }

    // layout
    private int gx() { return x0 + 10; }
    private int gy() { return y0 + 30; }
    private int px() { return x0 + 156; }
    private int py() { return y0 + 30; }
    private static final int PW = 144, PH = 122;
    private int by() { return py() + PH + 6; }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        Ui.panel(g, x0, y0, W, H);
        g.fill(x0 + 1, y0 + 1, x0 + W - 1, y0 + 22, Ui.BG2);
        g.fill(x0 + 1, y0 + 22, x0 + W - 1, y0 + 23, Ui.BORDER);
        g.drawString(font, "☺ " + title.getString(), x0 + 9, y0 + 8, Ui.TEXT, false);
        // tabs
        int tx = x0 + 128;
        tab(g, tx, "Все", !favTab, mx, my);
        tab(g, tx + 40, "★ Избранное", favTab, mx, my);
        // settings gear
        boolean gh = Ui.in(mx, my, x0 + W - 22, y0 + 4, 16, 15);
        Ui.button(g, font, x0 + W - 22, y0 + 4, 16, 15, Component.literal("⚙"), gh, true, false);

        List<String> l = list();
        String hoverId = null;
        for (int i = 0; i < 20; i++) {
            int cx = gx() + (i % COLS) * (CELL + 2), cy = gy() + (i / COLS) * (CELL + 2);
            if (i >= l.size()) { Ui.box(g, cx, cy, CELL, CELL, 0x40201A24, 0); continue; }
            String id = l.get(i);
            boolean hv = Ui.in(mx, my, cx, cy, CELL, CELL), sel = id.equals(selected), ok = allowed(id);
            if (hv) hoverId = id;
            Ui.box(g, cx, cy, CELL, CELL, hv ? Ui.CELL_HOVER : Ui.CELL, sel ? Ui.ACCENT : 0);
            if (sel) Ui.box(g, cx + 1, cy + 1, CELL - 2, CELL - 2, 0x00000000, Ui.ACCENT_SOFT);
            float bounce = hv ? (float) Math.sin(System.currentTimeMillis() / 90.0) * 0.8f : 0;
            g.pose().pushPose(); g.pose().translate(0, bounce, 0);
            Ui.icon(g, id, cx + 3, cy + 3, CELL - 6, ok ? 1f : 0.3f);
            g.pose().popPose();
            if (ClientEmotes.favorite(id)) {
                g.pose().pushPose(); g.pose().translate(cx + CELL - 7, cy + 1, 0); g.pose().scale(0.75f, 0.75f, 1);
                Ui.star(g, font, 0, 0, true); g.pose().popPose();
            }
            if (!ok) g.drawString(font, "✖", cx + CELL - 8, cy + CELL - 9, 0xFFB04050, false);
        }
        if (favTab && l.isEmpty()) {
            g.drawCenteredString(font, "Пока пусто", gx() + 69, gy() + 40, Ui.MUTED);
            g.drawCenteredString(font, "ПКМ по эмоции — в избранное", gx() + 69, gy() + 54, Ui.MUTED);
        }

        // info
        int iy = gy() + 4 * (CELL + 2) + 4;
        if (selected != null) {
            g.drawString(font, name(selected), gx(), iy, Ui.TEXT, true);
            EmoteDefs.Def d = EmoteDefs.get(selected);
            if (d != null) {
                String dur = String.format(Locale.ROOT, "%.1f с", d.duration);
                g.drawString(font, dur, gx() + 138 - font.width(dur), iy, Ui.MUTED, false);
                int yy = iy + 12;
                for (FormattedCharSequence line : font.split(Component.literal(d.description), 138)) {
                    if (yy > y0 + H - 22) break;
                    g.drawString(font, line, gx(), yy, Ui.MUTED, false); yy += 10;
                }
            }
        }

        // preview
        preview.render(g, px(), py(), PW, PH, selected, helmet);
        g.drawString(font, "⟲ тяните мышью", px() + 4, py() + PH - 11, 0x70FFFFFF, false);

        // buttons
        float cd = ClientEmotes.cooldownLeft();
        boolean canUse = selected != null && allowed(selected) && cd <= 0;
        String useLbl = cd > 0 ? String.format(Locale.ROOT, "%.1f с", cd) : "Использовать";
        int bx = px();
        Ui.button(g, font, bx, by(), 82, 18, Component.literal(useLbl), Ui.in(mx, my, bx, by(), 82, 18), canUse, true);
        boolean fav = selected != null && ClientEmotes.favorite(selected);
        Ui.button(g, font, bx + 85, by(), 18, 18, Component.literal("★").withStyle(s -> s.withColor(fav ? 0xFFC94A : 0xAAAAAA)),
                Ui.in(mx, my, bx + 85, by(), 18, 18), selected != null, false);
        Ui.button(g, font, bx + 106, by(), 18, 18, Component.literal(helmet ? "⛑" : "☻"),
                Ui.in(mx, my, bx + 106, by(), 18, 18), true, false);
        boolean own = ClientEmotes.own() != null;
        Ui.button(g, font, bx + 127, by(), 17, 18, Component.literal("✖"), Ui.in(mx, my, bx + 127, by(), 17, 18), own, false);

        // status line
        String status = null; int sc = Ui.MUTED;
        if (minecraft.getConnection() == null || !EmoteNetwork.CH.isRemotePresent(minecraft.getConnection().getConnection())) {
            status = "Сервер без модуля эмоций — доступен только предпросмотр"; sc = 0xFFE0A050;
        } else if (!ClientEmotes.serverEnabled) { status = "Эмоции отключены на сервере"; sc = 0xFFE07060; }
        else status = "ЛКМ — выбрать · двойной клик — показать · ПКМ — избранное";
        g.drawCenteredString(font, status, x0 + W / 2, y0 + H + 5, sc);

        // tooltips
        if (hoverId != null) g.renderTooltip(font, Component.literal(name(hoverId)), mx, my);
        else if (Ui.in(mx, my, bx + 85, by(), 18, 18)) g.renderTooltip(font, Component.literal(fav ? "Убрать из избранного" : "В избранное (колесо, до 8)"), mx, my);
        else if (Ui.in(mx, my, bx + 106, by(), 18, 18)) g.renderTooltip(font, Component.literal(helmet ? "Предпросмотр: в шлеме" : "Предпросмотр: без шлема"), mx, my);
        else if (Ui.in(mx, my, bx + 127, by(), 17, 18)) g.renderTooltip(font, Component.literal("Отменить текущую эмоцию"), mx, my);
        else if (gh) g.renderTooltip(font, Component.literal("Настройки эмоций"), mx, my);
    }

    private void tab(GuiGraphics g, int x, String s, boolean on, int mx, int my) {
        int w = font.width(s) + 12;
        boolean hv = Ui.in(mx, my, x, y0 + 4, w, 15);
        Ui.box(g, x, y0 + 4, w, 15, on ? Ui.ACCENT : hv ? Ui.CELL_HOVER : Ui.CELL, 0);
        g.drawString(font, s, x + 6, y0 + 8, on ? 0xFFFFFFFF : Ui.MUTED, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int b) {
        int tx = x0 + 128;
        if (Ui.in(mx, my, tx, y0 + 4, font.width("Все") + 12, 15)) { favTab = false; return true; }
        if (Ui.in(mx, my, tx + 40, y0 + 4, font.width("★ Избранное") + 12, 15)) { favTab = true; return true; }
        if (Ui.in(mx, my, x0 + W - 22, y0 + 4, 16, 15)) { minecraft.setScreen(new EmoteSettingsScreen(this)); return true; }
        List<String> l = list();
        for (int i = 0; i < Math.min(20, l.size()); i++) {
            int cx = gx() + (i % COLS) * (CELL + 2), cy = gy() + (i / COLS) * (CELL + 2);
            if (!Ui.in(mx, my, cx, cy, CELL, CELL)) continue;
            String id = l.get(i);
            if (b == 1) { ClientEmotes.toggleFavorite(id); return true; }
            long now = System.currentTimeMillis();
            if (id.equals(lastClickId) && now - lastClick < 300) { use(id); return true; }
            lastClick = now; lastClickId = id;
            if (!id.equals(selected)) { selected = id; preview.restart(); }
            return true;
        }
        int bx = px();
        if (Ui.in(mx, my, bx, by(), 82, 18) && selected != null) { use(selected); return true; }
        if (Ui.in(mx, my, bx + 85, by(), 18, 18) && selected != null) { ClientEmotes.toggleFavorite(selected); return true; }
        if (Ui.in(mx, my, bx + 106, by(), 18, 18)) { helmet = !helmet; return true; }
        if (Ui.in(mx, my, bx + 127, by(), 17, 18)) { ClientEmotes.cancel(); return true; }
        if (Ui.in(mx, my, px(), py(), PW, PH)) {
            if (b == 0) dragging = true; else preview.restart();
            return true;
        }
        return super.mouseClicked(mx, my, b);
    }

    private void use(String id) {
        if (ClientEmotes.request(id)) onClose();
    }

    @Override public boolean mouseDragged(double mx, double my, int b, double dx, double dy) {
        if (dragging) { preview.drag(dx, dy); return true; }
        return super.mouseDragged(mx, my, b, dx, dy);
    }

    @Override public boolean mouseReleased(double mx, double my, int b) { dragging = false; return super.mouseReleased(mx, my, b); }

    @Override public boolean keyPressed(int key, int scan, int mods) {
        if (ClientSetup.MENU.matches(key, scan)) { onClose(); return true; }
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) && selected != null) { use(selected); return true; }
        if (key == GLFW.GLFW_KEY_F && selected != null) { ClientEmotes.toggleFavorite(selected); return true; }
        if (key == GLFW.GLFW_KEY_TAB) { favTab = !favTab; return true; }
        List<String> l = list();
        int i = selected == null ? -1 : l.indexOf(selected), n = -1;
        if (key == GLFW.GLFW_KEY_RIGHT) n = i + 1; else if (key == GLFW.GLFW_KEY_LEFT) n = i - 1;
        else if (key == GLFW.GLFW_KEY_DOWN) n = i + COLS; else if (key == GLFW.GLFW_KEY_UP) n = i - COLS;
        if (n != -1 || key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_UP) {
            if (!l.isEmpty() && (key == GLFW.GLFW_KEY_RIGHT || key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_DOWN)) {
                n = Math.max(0, Math.min(l.size() - 1, n)); selected = l.get(n); preview.restart(); return true;
            }
        }
        return super.keyPressed(key, scan, mods);
    }
}
