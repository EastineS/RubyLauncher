package su.rubycon.emotes.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import org.joml.Matrix4f;
import su.rubycon.emotes.client.ClientEmotes;
import su.rubycon.emotes.client.ClientSetup;

import java.util.List;

/** Radial wheel with the 8 favourites. Hold the key, point, release. Centre = cancel / close. */
public class EmoteWheelScreen extends Screen {
    private static final int SLOTS = 8;
    private static final float R_IN = 30, R_OUT = 96;
    private final KeyMapping key;
    private final long opened = System.currentTimeMillis();
    private int hovered = -2;          // -1 = centre, -2 = nothing
    private boolean done;

    public EmoteWheelScreen(KeyMapping key) { super(Component.literal("Колесо эмоций")); this.key = key; }

    @Override public boolean isPauseScreen() { return false; }

    private List<String> favs() { return ClientEmotes.favorites(); }

    @Override
    public void tick() {
        if (!ClientSetup.rawDown(key)) finish();
    }

    private void finish() {
        if (done) return;
        done = true;
        List<String> f = favs();
        if (hovered >= 0 && hovered < f.size()) ClientEmotes.request(f.get(hovered));
        else if (hovered == -1) ClientEmotes.cancel();
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        float open = Math.min(1, (System.currentTimeMillis() - opened) / 120f);
        float k = 0.85f + 0.15f * (1 - (1 - open) * (1 - open));
        int cx = width / 2, cy = height / 2;
        g.fillGradient(0, 0, width, height, 0x50000000, 0x70000000);
        double dx = mx - cx, dy = my - cy, dist = Math.sqrt(dx * dx + dy * dy);
        List<String> f = favs();
        if (dist < R_IN * k) hovered = -1;
        else if (dist > 14) {
            double ang = Math.atan2(dx, -dy);            // 0 = up, clockwise
            if (ang < 0) ang += Math.PI * 2;
            hovered = (int) Math.floor((ang + Math.PI / SLOTS) / (Math.PI * 2 / SLOTS)) % SLOTS;
        }
        g.flush();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.POSITION_COLOR);
        Matrix4f m = g.pose().last().pose();
        float step = (float) (Math.PI * 2 / SLOTS), gap = 0.025f;
        for (int i = 0; i < SLOTS; i++) {
            boolean hv = i == hovered, has = i < f.size();
            int col = hv ? (has ? 0xE6D6334F : 0xC0403848) : (has ? 0xD61E1922 : 0xA0141118);
            float a0 = i * step - step / 2 + gap, a1 = (i + 1) * step - step / 2 - gap;
            float ro = (hv ? R_OUT + 6 : R_OUT) * k, ri = R_IN * k + 4;
            ring(bb, m, cx, cy, ri, ro, a0, a1, col);
            ring(bb, m, cx, cy, ro - 2, ro, a0, a1, hv ? 0xFFFF8098 : 0xFF3D3344);
        }
        ring(bb, m, cx, cy, 0, R_IN * k, 0, (float) Math.PI * 2, hovered == -1 ? 0xE6603040 : 0xD61E1922);
        BufferUploader.drawWithShader(bb.end());
        RenderSystem.enableCull();

        for (int i = 0; i < SLOTS; i++) {
            float a = i * step, r = (R_IN * k + R_OUT * k) / 2 + 2;
            int ix = Math.round(cx + (float) Math.sin(a) * r), iy = Math.round(cy - (float) Math.cos(a) * r);
            if (i < f.size()) {
                int s = i == hovered ? 34 : 28;
                Ui.icon(g, f.get(i), ix - s / 2, iy - s / 2, s, EmoteMenuScreen.allowed(f.get(i)) ? 1f : 0.35f);
            } else g.drawCenteredString(font, "+", ix, iy - 4, 0x60FFFFFF);
            g.drawString(font, String.valueOf(i + 1), ix + 13, iy + 8, 0x60FFFFFF, false);
        }
        String center;
        if (hovered >= 0 && hovered < f.size()) center = EmoteMenuScreen.name(f.get(hovered));
        else if (hovered >= 0) center = "Пусто";
        else center = ClientEmotes.own() != null ? "Отменить" : "Закрыть";
        g.drawCenteredString(font, hovered == -1 ? "✖" : "☺", cx, cy - 10, Ui.TEXT);
        g.pose().pushPose(); g.pose().translate(cx, cy + 2, 0); g.pose().scale(0.75f, 0.75f, 1);
        g.drawCenteredString(font, center, 0, 0, Ui.TEXT);
        g.pose().popPose();
        String hint = f.isEmpty() ? "Избранное пусто — добавьте эмоции в меню (нажмите G)" : "Отпустите клавишу, чтобы показать эмоцию · 1–8";
        g.drawCenteredString(font, hint, cx, cy + (int) (R_OUT * k) + 14, 0xB0FFFFFF);
    }

    private static void ring(BufferBuilder bb, Matrix4f m, float cx, float cy, float ri, float ro, float a0, float a1, int col) {
        int seg = Math.max(2, (int) Math.ceil((a1 - a0) / 0.08f));
        int a = col >>> 24, r = col >> 16 & 255, gr = col >> 8 & 255, b = col & 255;
        for (int s = 0; s < seg; s++) {
            float t0 = a0 + (a1 - a0) * s / seg, t1 = a0 + (a1 - a0) * (s + 1) / seg;
            float s0 = (float) Math.sin(t0), c0 = -(float) Math.cos(t0), s1 = (float) Math.sin(t1), c1 = -(float) Math.cos(t1);
            float x0i = cx + s0 * ri, y0i = cy + c0 * ri, x1i = cx + s1 * ri, y1i = cy + c1 * ri;
            float x0o = cx + s0 * ro, y0o = cy + c0 * ro, x1o = cx + s1 * ro, y1o = cy + c1 * ro;
            bb.vertex(m, x0i, y0i, 0).color(r, gr, b, a).endVertex();
            bb.vertex(m, x1o, y1o, 0).color(r, gr, b, a).endVertex();
            bb.vertex(m, x0o, y0o, 0).color(r, gr, b, a).endVertex();
            bb.vertex(m, x0i, y0i, 0).color(r, gr, b, a).endVertex();
            bb.vertex(m, x1i, y1i, 0).color(r, gr, b, a).endVertex();
            bb.vertex(m, x1o, y1o, 0).color(r, gr, b, a).endVertex();
        }
    }

    @Override public boolean mouseClicked(double mx, double my, int b) {
        if (b == 0) { finish(); return true; }
        if (b == 1) { done = true; onClose(); return true; }
        return true;
    }

    @Override public boolean keyPressed(int k, int scan, int mods) {
        if (k >= '1' && k <= '8') { hovered = k - '1'; finish(); return true; }
        return super.keyPressed(k, scan, mods);
    }
}
