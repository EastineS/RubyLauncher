import sys, math, json, os
sys.path.insert(0, '/data/art')
import numpy as np
from PIL import Image
from emotes import E
TEX = '/data/emotes-mod/src/main/resources/assets/rubycon_emotes/textures/emote'
SPR = {}
def spr(n):
    if n not in SPR: SPR[n] = Image.open(f'{TEX}/{n}.png').convert('RGBA')
    return SPR[n]

# ---------------- evaluator (mirrors EmoteAnimator.java exactly) ----------------
INTRO, FADEIN, OUTRO = 0.3, 0.15, 0.4
def back_out(x):
    c1 = 1.70158; c3 = c1 + 1; x -= 1
    return 1 + c3 * x**3 + c1 * x**2
def sample(keys, t, smooth, n):
    if not keys: return None
    if t <= keys[0][0]: return keys[0][1:1+n] if len(keys[0]) > n else keys[0][1:] + [keys[0][-1]]*(n-len(keys[0])+1)
    for a, b in zip(keys, keys[1:]):
        if t <= b[0]:
            f = (t - a[0]) / max(1e-6, b[0] - a[0])
            if smooth: f = f*f*(3-2*f)
            va = pad(a[1:], n); vb = pad(b[1:], n)
            return [va[i] + (vb[i]-va[i])*f for i in range(n)]
    return pad(keys[-1][1:], n)
def pad(v, n):
    v = list(v)
    if n == 2 and len(v) == 1: return [v[0], v[0]]   # uniform scale
    while len(v) < n: v.append(0.0)
    return v[:n]
def step(keys, t):
    v = keys[0][1]
    for k in keys:
        if t >= k[0]: v = k[1]
    return int(v)

def evaluate(em, t, reduced=False):
    """returns list of quads: dict(tex, frame, frames, x,y,z, w,h, rot, alpha, flip, space)"""
    out = []; dur = em['duration']
    for li, ly in enumerate(em['layers']):
        insts = ly.get('instances') or [dict(offset=[0,0,0], phase=0, flip=False, scale=1, rot=0)]
        tr = ly.get('tracks', {}); smooth = ly.get('ease') == 'smooth'
        loop = ly.get('loop', 0); start = ly.get('start', 0)
        for ii, ins in enumerate(insts):
            lt = t - start - ins.get('phase', 0)
            if lt < 0: continue
            if loop > 0: lt = lt % loop
            p = sample(tr.get('pos'), lt, smooth, 3) or [0, 0, 0]
            s = sample(tr.get('scale'), lt, smooth, 2) or [1, 1]
            r = (sample(tr.get('rot'), lt, smooth, 1) or [0])[0]
            a = (sample(tr.get('alpha'), lt, smooth, 1) or [1])[0]
            if ly.get('intense') and reduced:
                s = [1 + (s[0]-1)*0.3, 1 + (s[1]-1)*0.3]; r *= 0.3; a = 1 + (a-1)*0.3
            x = ly['pos'][0] + ins['offset'][0] + p[0]
            y = ly['pos'][1] + ins['offset'][1] + p[1]
            z = ly['pos'][2] + ins['offset'][2] + p[2]
            sh = ly.get('shake')
            if sh and not reduced:
                seed = li*1.7 + ii*3.1
                x += sh[0]*math.sin(2*math.pi*sh[1]*t + seed)
                y += sh[0]*math.sin(2*math.pi*sh[1]*1.37*t + seed*2.1)
            k = ins.get('scale', 1)
            env = 1.0
            if ly.get('pop', True):
                if t < INTRO: env = back_out(t/INTRO)
                a *= min(1.0, t/FADEIN)
            rem = dur - t
            if rem < OUTRO:
                q = max(0, rem/OUTRO); a *= q; env *= 0.85 + 0.15*q
            rot = r + ins.get('rot', 0)
            flip = ins.get('flip', False)
            if flip: x = -x; rot = -rot
            frames = ly.get('frames', 1); fr = 0
            if frames > 1:
                if 'frame' in tr: fr = step(tr['frame'], lt) % frames
                elif ly.get('fps'): fr = int(lt*ly['fps']) % frames
            out.append(dict(tex=ly['tex'], frame=fr, frames=frames, x=x, y=y, z=z, w=ly['size'][0]*s[0]*k*env, h=ly['size'][1]*s[1]*k*env,
                            rot=rot, alpha=max(0, min(1, a)), flip=flip, space=ly['space'], li=li))
    return out

# ---------------- dummy character (own design) ----------------
def make_skin():
    sk = np.zeros((64, 64, 4), np.uint8)
    H, Hs, S, Ss, W, P, M, SH, SHs = [(*bytes.fromhex(h), 255) for h in
        ['5b3a29', '432a1e', 'e8b48c', 'd09a74', 'ffffff', '3d5fd9', 'a8644a', '2fa39b', '217a74']]
    face = ['HHHHHHHH', 'HHHhHHhH', 'HhSSSShH', 'SSSSSSSS', 'SWPSSPWS', 'sSSSSSSs', 'SSSMMSSS', 'ssSSSSss']
    cm = dict(H=H, h=Hs, S=S, s=Ss, W=W, P=P, M=M)
    def fill(x0, y0, w, h, col): sk[y0:y0+h, x0:x0+w] = col
    # head: top(8,0) bottom(16,0) right(0,8) front(8,8) left(16,8) back(24,8)
    fill(8, 0, 8, 8, H); fill(16, 0, 8, 8, Ss)
    for fx in (0, 16): fill(fx, 8, 8, 8, S); fill(fx, 8, 8, 3, H); fill(fx + (6 if fx == 0 else 0), 11, 2, 2, H)
    fill(24, 8, 8, 8, H); fill(24, 14, 8, 2, Hs)
    for y, row in enumerate(face):
        for x, ch in enumerate(row): sk[8+y, 8+x] = cm[ch]
    # body (16,16) front (20,20) 8x12
    fill(16, 16, 24, 16, SH); fill(20, 20, 8, 12, SH); fill(20, 20, 8, 1, SHs); fill(23, 21, 2, 1, S)
    # arms (40,16) front (44,20) 4x12
    fill(40, 16, 16, 16, SH); fill(44, 28, 4, 4, S); fill(40, 28, 16, 4, S); fill(48, 16, 4, 4, S)
    fill(32, 48, 16, 16, SH); fill(36, 60, 4, 4, S); fill(32, 60, 16, 4, S)  # left arm
    return Image.fromarray(sk, 'RGBA')
SKIN = make_skin()
SKIN.save('/data/art/dummy_skin.png')

def front(img_box):
    return SKIN.crop(img_box)

def draw_quad(canvas, q, P, x0, y1):
    im = spr(q['tex'])
    if q['frames'] > 1:
        fh = im.height // q['frames']; im = im.crop((0, q['frame']*fh, im.width, (q['frame']+1)*fh))
    if q['flip']: im = im.transpose(Image.FLIP_LEFT_RIGHT)
    w = max(1, int(round(abs(q['w'])*P))); h = max(1, int(round(abs(q['h'])*P)))
    if w < 1 or h < 1 or q['alpha'] <= 0.02: return
    im = im.resize((w, h), Image.NEAREST)
    if abs(q['rot']) > 0.01: im = im.rotate(q['rot'], Image.NEAREST, expand=True)
    if q['alpha'] < 1:
        a = np.array(im); a[..., 3] = (a[..., 3] * q['alpha']).astype(np.uint8); im = Image.fromarray(a)
    cx = (q['x'] - x0) * P; cy = (y1 - q['y']) * P
    canvas.alpha_composite(im, (int(round(cx - im.width/2)), int(round(cy - im.height/2)))) if -im.width < cx < canvas.width+im.width else None

def paste_safe(canvas, im, x, y):
    tmp = Image.new('RGBA', canvas.size, (0,0,0,0))
    tmp.paste(im, (x, y)); canvas.alpha_composite(tmp)

def scene(em, t, P=10, win=(-14, 14, -12, 20), bg=(0,0,0,0), body=True, helmet=False, show_head=True):
    x0, x1, y0, y1 = win
    W, Hh = int((x1-x0)*P), int((y1-y0)*P)
    c = Image.new('RGBA', (W, Hh), bg)
    quads = evaluate(em, t)
    for q in quads:
        if q['space'] == 'face' and helmet: q['z'] += 1.1
    def part(box, ux, uy):  # box = skin uv rect, (ux,uy) = top-left in units
        im = SKIN.crop(box); im = im.resize((im.width*P, im.height*P), Image.NEAREST)
        paste_safe(c, im, int((ux-x0)*P), int((y1-uy)*P))
    layers = sorted(quads, key=lambda q: q['z'])
    i = 0
    def until(z):
        nonlocal i
        while i < len(layers) and layers[i]['z'] < z:
            draw_quad(c, layers[i], P, x0, y1); i += 1
    if body:
        until(2)
        part((44, 20, 48, 32), -8, -4); part((36, 52, 40, 64), 4, -4)  # arms
        part((20, 20, 28, 32), -4, -4)
    until(4)
    if show_head: part((8, 8, 16, 16), -4, 4)
    if helmet:
        hm = Image.new('RGBA', (int(9.6*P), int(4.2*P)), (180, 184, 196, 255))
        paste_safe(c, hm, int((-4.8-x0)*P), int((y1-5.0)*P))
        paste_safe(c, Image.new('RGBA', (int(9.6*P), int(0.6*P)), (120, 124, 140, 255)), int((-4.8-x0)*P), int((y1-1.4)*P))
    until(1e9)
    return c

ICON_T = dict(anger=0.55, rage=0.75, laugh=0.9, sad=1.35, cry=1.0, surprise=0.8, shock=0.6, confused=1.75, think=1.25, embarrassed=1.2,
              love=1.75, delight=1.32, fright=0.9, awkward=1.0, suspicion=1.0, smug=1.0, sleepy=2.1, dizzy=0.5, facepalm=0.62, mischief=1.2)
if __name__ == '__main__':
    os.makedirs('/data/art/out/gif', exist_ok=True); os.makedirs(f'{TEX}/../icon', exist_ok=True)
    tiles = []
    for em in E:
        t = ICON_T[em['id']]; ic = em['icon']; half = ic['size']/2
        face = em['placement'] == 'face'
        big = scene(em, t, P=8, win=(-16, 16, -14, 18), body=False, show_head=face)
        bb = big.getbbox() or (0, 0, 1, 1)
        crop = big.crop(bb); k = min(60/crop.width, 60/crop.height)
        crop = crop.resize((max(1, int(crop.width*k)), max(1, int(crop.height*k))), Image.NEAREST if k >= 1 else Image.BOX)
        icon = Image.new('RGBA', (64, 64), (0, 0, 0, 0)); icon.alpha_composite(crop, ((64-crop.width)//2, (64-crop.height)//2))
        icon.save(f'{TEX}/../icon/{em["id"]}.png')
        frames = [scene(em, f/20, P=10, bg=(54, 58, 74, 255)) for f in range(int(em['duration']*20))]
        frames[0].save(f'/data/art/out/gif/{em["id"]}.gif', save_all=True, append_images=frames[1:], duration=50, loop=0, disposal=2)
        tiles.append((em, scene(em, t, P=10, bg=(54, 58, 74, 255)), icon))
    # contact sheet with names
    from PIL import ImageDraw, ImageFont
    f = ImageFont.truetype('/usr/share/fonts/liberation-sans/LiberationSans-Bold.ttf', 18) if os.path.exists('/usr/share/fonts/liberation-sans/LiberationSans-Bold.ttf') else ImageFont.load_default()
    tw, th = 280, 350
    sheet = Image.new('RGBA', (tw*5, th*4), (34, 36, 48, 255)); d = ImageDraw.Draw(sheet)
    for i, (em, im, icon) in enumerate(tiles):
        x, y = (i % 5)*tw, (i//5)*th
        sheet.alpha_composite(im, (x, y)); d.text((x+10, y+322), f'{i+1}. {em["name"]}', fill=(240, 230, 200), font=f)
        sheet.alpha_composite(Image.new('RGBA',(68,68),(20,22,30,255)), (x+tw-70, y+2)); sheet.alpha_composite(icon, (x+tw-68, y+4))
    sheet.save('/data/art/out/all_emotes_preview.png')
    json.dump([dict(id=e['id'], name=e['name']) for e in E], open('/data/art/out/list.json', 'w'), ensure_ascii=False)
    print('ok')
