# Pixel-art toolkit v2: shapes are authored in "design units" (old 32px grid) and
# rasterised at K x resolution; parts get volumetric (dome) cel shading with hue-shifted ramps.
import numpy as np, colorsys
from PIL import Image
K = 2
def hexc(h, a=255):
    h = h.lstrip('#'); return (int(h[0:2],16), int(h[2:4],16), int(h[4:6],16), a)
def shift(m, dx, dy):
    out = np.zeros_like(m); h, w = m.shape
    xs = slice(max(dx,0), w+min(dx,0)); xd = slice(max(-dx,0), w+min(-dx,0))
    ys = slice(max(dy,0), h+min(dy,0)); yd = slice(max(-dy,0), h+min(-dy,0))
    out[ys, xs] = m[yd, xd]; return out
def dist_inside(m, maxd=40):
    d = np.zeros(m.shape, float); cur = m.copy()
    for i in range(maxd):
        if not cur.any(): break
        d[cur] += 1
        cur = cur & shift(cur,1,0) & shift(cur,-1,0) & shift(cur,0,1) & shift(cur,0,-1)
    return d
def ramp(base):
    r, g, b, a = hexc(base) if isinstance(base, str) else base
    h, l, s = colorsys.rgb_to_hls(r/255, g/255, b/255)
    def mk(dh, dl, ds):
        hh = (h + dh) % 1; ll = min(1, max(0, l + dl)); ss = min(1, max(0, s + ds))
        rr, gg, bb = colorsys.hls_to_rgb(hh, ll, ss); return (int(rr*255), int(gg*255), int(bb*255), 255)
    # deep shadow, shadow, base, light, highlight (shadows shift to purple/blue, lights to warm)
    tow = lambda target, amt: ((target - h + 0.5) % 1 - 0.5) * amt
    return [mk(tow(0.72, 0.18), -0.26, 0.05), mk(tow(0.72, 0.09), -0.13, 0.03), mk(0, 0, 0),
            mk(tow(0.14, 0.06), 0.12, 0.0), mk(tow(0.14, 0.1), 0.26, -0.05)]
def outline_col(base):
    r = ramp(base)[0]; return tuple(int(c*0.45) for c in r[:3]) + (255,)

class Canvas:
    def __init__(s, w, h):
        s.W, s.H = int(w*K), int(h*K); s.w, s.h = w, h
        s.img = np.zeros((s.H, s.W, 4), np.uint8)
        yy, xx = np.mgrid[0:s.H, 0:s.W]
        s.X = (xx + 0.5)/K; s.Y = (yy + 0.5)/K
    def circle(s, cx, cy, r): return (s.X-cx)**2 + (s.Y-cy)**2 <= r*r
    def ellipse(s, cx, cy, rx, ry, ang=0):
        a = np.radians(ang); dx = s.X-cx; dy = s.Y-cy
        u = dx*np.cos(a)+dy*np.sin(a); v = -dx*np.sin(a)+dy*np.cos(a)
        return (u/rx)**2 + (v/ry)**2 <= 1
    def rect(s, x0, y0, x1, y1): return (s.X>=x0)&(s.X<x1)&(s.Y>=y0)&(s.Y<y1)
    def ring(s, cx, cy, r, t):
        d = np.sqrt((s.X-cx)**2+(s.Y-cy)**2); return (d<=r)&(d>=r-t)
    def capsule(s, x0, y0, x1, y1, r):
        px, py = s.X-x0, s.Y-y0; dx, dy = x1-x0, y1-y0
        L = dx*dx+dy*dy or 1e-6
        t = np.clip((px*dx+py*dy)/L, 0, 1)
        return (px-t*dx)**2+(py-t*dy)**2 <= r*r
    def poly(s, pts):
        from matplotlib.path import Path
        m = Path(pts).contains_points(np.c_[s.X.ravel(), s.Y.ravel()]); return m.reshape(s.H, s.W)
    def heart(s, cx, cy, r):
        x = (s.X-cx)/r; y = -(s.Y-cy)/r + 0.25
        return (x*x + y*y - 1)**3 - x*x*y**3 <= 0
    def star(s, cx, cy, ro, ri, n=5, rot=-90):
        pts = []
        for i in range(n*2):
            a = np.radians(rot + i*180/n); r = ro if i%2==0 else ri
            pts.append((cx+r*np.cos(a), cy+r*np.sin(a)))
        return s.poly(pts)
    def drop(s, cx, cy, r, tip):
        c = s.circle(cx, cy, r)
        tri = s.poly([(cx-r*0.92, cy-r*0.38), (cx, cy-tip), (cx+r*0.92, cy-r*0.38)])
        # round the sides of the cone slightly
        return c | tri | (s.ellipse(cx, cy-(tip-r)*0.45, r*0.82, (tip)*0.55) & (s.Y < cy))
    def put(s, mask, col): s.img[mask] = hexc(col) if isinstance(col, str) else col
    def part(s, mask, base, light=None, shadow=None, sw=2, lw=1, shine=None, flat=False, gloss=True, dome=1.0):
        """volumetric cel shading. legacy light/shadow args are ignored in favour of an auto ramp"""
        if not mask.any(): return
        R = ramp(base)
        if flat:
            s.img[mask] = R[2]; return
        d = dist_inside(mask)
        md = max(1.0, np.percentile(d[mask], 92))
        hgt = np.sqrt(np.clip(d / md, 0, 1)) * dome
        gy, gx = np.gradient(hgt)
        # light from top-left-front
        L = np.array([-0.55, -0.65, 0.52]); L /= np.linalg.norm(L)
        nz = np.ones_like(hgt) * 0.18
        n = np.stack([-gx, -gy, nz], -1); n /= np.linalg.norm(n, axis=-1, keepdims=True) + 1e-9
        lum = (n @ L)
        # tone selection
        tone = np.full(mask.shape, 2)
        tone[lum < 0.25] = 1; tone[lum < -0.15] = 0
        tone[lum > 0.62] = 3
        # rim shadow on bottom-right edge
        rim = mask & ~shift(mask, -K, -K)
        tone[rim] = np.minimum(tone[rim], 1)
        for t in range(5):
            s.img[mask & (tone == t)] = R[t]
        if gloss:
            # glossy specular: small blob near top-left inside the shape
            ys, xs = np.nonzero(mask)
            x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
            cx = x0 + (x1-x0)*0.3; cy = y0 + (y1-y0)*0.28
            rr = max(1.0, min(x1-x0, y1-y0) * 0.09)
            yy, xx = np.mgrid[0:s.H, 0:s.W]
            sp = ((xx-cx)**2/(rr*1.6)**2 + (yy-cy)**2/(rr)**2 <= 1) & (d > K*1.2)
            s.img[sp & mask] = R[4]
            sp2 = ((xx-cx)**2 + (yy-cy)**2 <= (rr*0.55)**2) & (d > K*1.2)
            s.img[sp2 & mask] = (255, 255, 255, 255)
        if shine:
            for (x, y) in shine:
                s.put(s.rect(x, y, x+1, y+1) & mask, '#ffffff')
    def outline(s, col='#1e1424', width=None, diag=True):
        width = width or K
        a = s.img[..., 3] > 0; acc = a.copy()
        for i in range(width):
            n = shift(acc,1,0)|shift(acc,-1,0)|shift(acc,0,1)|shift(acc,0,-1)
            if diag and i == width-1 and width > 1: pass
            elif diag: n |= shift(acc,1,1)|shift(acc,-1,-1)|shift(acc,1,-1)|shift(acc,-1,1)
            acc = acc | n
        s.img[acc & ~a] = hexc(col) if isinstance(col, str) else col
    def inline(s, mask, col):
        n = mask.copy()
        for i in range(K):
            n = n | shift(n,1,0)|shift(n,-1,0)|shift(n,0,1)|shift(n,0,-1)
        s.img[n & ~mask] = hexc(col)
    def erase(s, mask): s.img[mask] = (0,0,0,0)
    def image(s): return Image.fromarray(s.img, 'RGBA')
