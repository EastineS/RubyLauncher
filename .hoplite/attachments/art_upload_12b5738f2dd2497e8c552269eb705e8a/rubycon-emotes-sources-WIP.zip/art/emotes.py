# Single source of truth for the 20 emotes. Units: model pixels (1/16 block).
# Origin = head centre. x -> viewer's right, y -> up, z -> towards viewer. Face plane z = 4.
import json, math
def L(tex, size, pos, space='billboard', **kw):
    d = dict(tex=tex, size=list(size), pos=list(pos), space=space); d.update(kw); return d
def I(offset=(0,0,0), phase=0.0, flip=False, scale=1.0, rot=0.0):
    return dict(offset=list(offset), phase=phase, flip=flip, scale=scale, rot=rot)
FZ = 4.06
E = []
def emote(id, name, dur, placement, layers, icon=(0, 2, 16), desc=''):
    E.append(dict(id=id, name=name, duration=dur, placement=placement, layers=layers, icon=dict(cx=icon[0], cy=icon[1], size=icon[2], t=None), desc=desc))

emote('anger', 'Злость', 4.0, 'side', [
    L('vein', (5, 5), (5.2, 4.6, 2), loop=0.6, ease='smooth', intense=True,
      tracks=dict(scale=[[0, 1], [0.1, 1.32], [0.3, 0.94], [0.6, 1]]), shake=[0.22, 9]),
], icon=(1.5, 2.5, 16), desc='Красный символ злости у виска: резко появляется, пульсирует и дёргается')

emote('rage', 'Ярость', 4.5, 'side', [
    L('rage_shade', (8, 3.5), (0, 2.25, FZ), space='face', loop=0.7, secondary=True,
      tracks=dict(alpha=[[0, 0.75], [0.35, 1], [0.7, 0.75]])),
    L('steam', (3.6, 3), (5.2, -0.5, 0), loop=0.8, pop=False,
      tracks=dict(pos=[[0, 0, 0], [0.8, 4.2, 2.2]], scale=[[0, 0.35], [0.3, 1.05], [0.8, 1.45]], alpha=[[0, 0], [0.08, 1], [0.5, 0.9], [0.8, 0]]),
      instances=[I(phase=0), I(phase=0.4), I(phase=0.2, flip=True), I(phase=0.6, flip=True)]),
    L('vein', (5.4, 5.4), (5.4, 4.8, 2), loop=0.42, ease='smooth', intense=True, shake=[0.35, 12],
      tracks=dict(scale=[[0, 1], [0.08, 1.38], [0.24, 0.92], [0.42, 1]]),
      instances=[I(), I(offset=(0.6, -0.8, 0), phase=0.2, flip=True, scale=0.85)]),
], icon=(0, 1.5, 16), desc='Два символа злости и пар, вырывающийся короткими порциями')

emote('laugh', 'Смех', 4.0, 'face', [
    L('laugh_eyes', (8, 3), (0, -0.4, FZ), space='face', loop=0.36, ease='smooth',
      tracks=dict(pos=[[0, 0, 0], [0.18, 0, 0.3], [0.36, 0, 0]])),
    L('tear', (2.3, 3.0), (4.6, -0.4, 3.0), loop=0.72, pop=False,
      tracks=dict(pos=[[0, 0, 0], [0.36, 2.6, 1.6], [0.72, 4.8, -1.8]], rot=[[0, -35], [0.72, -120]],
                  scale=[[0, 0.5], [0.15, 1], [0.72, 0.9]], alpha=[[0, 0], [0.06, 1], [0.55, 1], [0.72, 0]]),
      instances=[I(phase=0), I(phase=0.36, scale=0.8), I(phase=0.18, flip=True), I(phase=0.54, flip=True, scale=0.8)]),
], icon=(0, 0, 16), desc='Прищуренные глаза и крупные слёзы смеха, вылетающие по бокам')

emote('sad', 'Грусть', 5.0, 'above', [
    L('raindrop', (1.4, 2.1), (0, 0, 0.3), loop=1.0, pop=False,
      tracks=dict(pos=[[0, 0, 7.4], [1.0, 0, 4.3]], alpha=[[0, 0], [0.1, 1], [0.8, 1], [1.0, 0]]),
      instances=[I(offset=(-2.4, 0, 0), phase=0.0), I(offset=(0.6, 0, 0), phase=0.55), I(offset=(2.8, 0, 0), phase=0.3)]),
    L('raincloud', (9, 6), (0, 9.6, 0), loop=2.4, ease='smooth',
      tracks=dict(pos=[[0, 0, 0.5], [1.2, 0, -0.3], [2.4, 0, 0.5]])),
], icon=(0, 5, 16), desc='Маленькая синяя тучка над головой, из которой падают редкие капли')

emote('cry', 'Рыдания', 5.0, 'face', [
    L('tear_stream', (2.0, 10), (2.0, -5.6, FZ + 0.02), space='face', frames=4, fps=10, loop=0.5, ease='smooth',
      tracks=dict(scale=[[0, 1, 1], [0.25, 1.18, 1], [0.5, 1, 1]]),
      instances=[I(), I(flip=True, phase=0.25)]),
    L('tear', (1.5, 2.0), (2.6, -10.4, 4.2), loop=0.55, pop=False,
      tracks=dict(pos=[[0, 0, 0], [0.55, 0.9, -3.2]], rot=[[0, 180], [0.55, 200]], alpha=[[0, 1], [0.4, 1], [0.55, 0]]),
      instances=[I(), I(phase=0.27, offset=(-0.8, 0, 0)), I(flip=True, phase=0.12), I(flip=True, phase=0.4, offset=(-0.8, 0, 0))]),
], icon=(0, -3, 16), desc='Два преувеличенно больших потока слёз, распадающиеся на капли')

emote('surprise', 'Удивление', 3.0, 'above', [
    L('exclam', (3.4, 6.8), (0, 9.2, 0), pop=False, ease='smooth',
      tracks=dict(pos=[[0, 0, -5], [0.16, 0, 1.4], [0.3, 0, 0], [0.42, 0, 0.45], [0.56, 0, 0]],
                  scale=[[0, 0.55, 1.6], [0.16, 0.72, 1.42], [0.3, 1.3, 0.72], [0.42, 0.9, 1.14], [0.56, 1.0, 1.0]],
                  alpha=[[0, 0], [0.05, 1]])),
], icon=(0, 5, 16), desc='Большой жёлтый восклицательный знак, который выстреливает вверх и пружинит')

emote('shock', 'Шок', 3.5, 'above', [
    L('shock_lines', (15, 15), (0, 2.2, -0.5), loop=0.24, secondary=True, intense=True,
      tracks=dict(scale=[[0, 0.94], [0.12, 1.06], [0.24, 0.94]], alpha=[[0, 1], [0.12, 0.8], [0.24, 1]])),
    L('exclam_red', (2.6, 5.2), (0, 7.4, 0.5), pop=False, shake=[0.28, 15], intense=True,
      tracks=dict(scale=[[0, 0], [0.1, 1.35], [0.22, 1]], alpha=[[0, 0], [0.04, 1]]),
      instances=[I(offset=(-3.6, -0.9, 0), rot=24, phase=0.04), I(offset=(0, 0.6, 0)), I(offset=(3.6, -0.9, 0), rot=-24, phase=0.08)]),
], icon=(0, 3, 18), desc='Несколько восклицательных знаков и ломаные линии, раскрывающиеся веером')

emote('confused', 'Непонимание', 4.5, 'above', [
    L('question', (4.5, 6), (2.2, 9.2, 0), loop=1.6, ease='smooth',
      tracks=dict(rot=[[0, -16], [0.8, 16], [1.6, -16]], pos=[[0, 0, 0], [0.4, 0, 0.4], [0.8, 0, 0], [1.2, 0, 0.4], [1.6, 0, 0]])),
    L('question', (4.5, 6), (-3.6, 8.0, 0), loop=1.6, ease='smooth', start=0.9,
      tracks=dict(rot=[[0, 14], [0.8, -14], [1.6, 14]]), instances=[I(scale=0.5)]),
    L('question', (4.5, 6), (6.9, 6.4, 0), loop=1.6, ease='smooth', start=1.2,
      tracks=dict(rot=[[0, -10], [0.8, 18], [1.6, -10]]), instances=[I(scale=0.42)]),
], icon=(0.5, 5, 16), desc='Крупный вопросительный знак качается, затем появляются два маленьких')

emote('think', 'Задумчивость', 6.0, 'above', [
    L('bubble', (1.1, 1.1), (2.6, 5.4, 1), instances=[I()]),
    L('bubble', (1.6, 1.6), (3.6, 7.0, 1), start=0.12),
    L('thought_cloud', (8.4, 5.9), (5.4, 10.6, 0), start=0.24, loop=3.0, ease='smooth',
      tracks=dict(pos=[[0, 0, 0], [1.5, 0, 0.4], [3.0, 0, 0]])),
    L('dot', (1.3, 1.3), (5.4, 10.8, 0.2), start=0.4, loop=1.2,
      tracks=dict(alpha=[[0, 0.25], [0.15, 1], [0.6, 1], [0.75, 0.25], [1.2, 0.25]], scale=[[0, 0.85], [0.15, 1.2], [0.3, 1], [1.2, 0.85]],
                  pos=[[0, 0, 0], [3.0, 0, 0.4]]),
      instances=[I(offset=(-2.1, 0, 0)), I(phase=0.22), I(offset=(2.1, 0, 0), phase=0.44)]),
], icon=(3.5, 6.0, 16), desc='Небольшое облачко мыслей, в котором по очереди загораются три точки')

emote('embarrassed', 'Смущение', 4.5, 'face', [
    L('blush', (3.1, 1.8), (2.5, -1.7, FZ), space='face', pop=False,
      tracks=dict(alpha=[[0, 0], [0.8, 1]]), instances=[I(), I(flip=True)]),
    L('heart_pink', (2.5, 2.3), (5.3, 3.2, 2), loop=1.0, ease='smooth',
      tracks=dict(pos=[[0, 0, 0], [0.15, 0, 1.3], [0.3, 0, 0], [0.4, 0, 0.45], [0.5, 0, 0], [1.0, 0, 0]],
                  rot=[[0, 0], [0.15, -14], [0.3, 9], [0.42, -4], [0.5, 0], [1.0, 0]],
                  scale=[[0, 1.15, 0.85], [0.12, 0.9, 1.12], [0.3, 1.12, 0.88], [0.45, 1, 1], [1.0, 1, 1]])),
], icon=(1.5, 0.5, 14), desc='Розовый румянец и маленькое сердечко, которое неловко подпрыгивает')

emote('love', 'Любовь', 4.5, 'side', [
    L('heart', (3.0, 2.75), (0, 0, 1.5), loop=1.5, pop=False, ease='smooth',
      tracks=dict(pos=[[0, 0, 0], [1.5, 0, 3.8]], scale=[[0, 0.3], [0.35, 1.15], [0.55, 0.95], [1.5, 0.75]],
                  alpha=[[0, 0], [0.12, 1], [1.1, 1], [1.5, 0]], rot=[[0, -8], [0.75, 8], [1.5, -8]]),
      instances=[I((-5.8, 0.5, 0), 0.0), I((5.8, 2.0, 0), 0.3, scale=0.9), I((-3.6, 6.2, 0), 0.6, scale=0.8),
                 I((3.4, 7.0, 0), 0.9), I((0.2, 9.2, 0), 1.2, scale=0.7), I((6.5, -2.5, 0), 0.75, scale=0.6)]),
], icon=(0, 3, 18), desc='Сердечки вокруг головы, которые увеличиваются и всплывают вверх')

emote('delight', 'Восторг', 4.0, 'side', [
    L('sparkle', (1.6, 1.6), (0, 0, 3), loop=0.8, secondary=True, intense=True,
      tracks=dict(scale=[[0, 0.2], [0.2, 1.2], [0.4, 0.2], [0.8, 0.2]], alpha=[[0, 0], [0.1, 1], [0.4, 0], [0.8, 0]]),
      instances=[I((-3.2, 5.6, 0), 0.1), I((6.8, 1.0, 0), 0.5), I((-6.6, -0.6, 0), 0.3)]),
    L('star_gold', (3.6, 3.6), (0, 0, 3), loop=1.2, pop=False,
      tracks=dict(scale=[[0, 0.2], [0.14, 1.28], [0.3, 0.9], [0.55, 1.0], [1.2, 0.3]], alpha=[[0, 0], [0.08, 1], [0.95, 1], [1.2, 0]],
                  rot=[[0, -25], [1.2, 30]]),
      instances=[I((-5.6, 3.0, 0), 0.0), I((5.6, 4.6, 0), 0.3), I((5.0, -2.4, 0), 0.6, scale=0.75), I((-5.2, -2.2, 0), 0.9, scale=0.8)]),
], icon=(0, 1, 16), desc='Крупные золотые звёздочки около лица, вспыхивающие по очереди')

emote('fright', 'Испуг', 4.0, 'face', [
    L('fear_lines', (8, 5), (0, 1.6, FZ), space='face', pop=False, shake=[0.12, 16], intense=True,
      tracks=dict(alpha=[[0, 0], [0.35, 1]])),
    L('ghost', (3.6, 4.2), (0, 6.5, -0.6), loop=2.0, pop=False, ease='smooth',
      tracks=dict(pos=[[0, 0, -3.5], [0.55, 0.4, 2.6], [1.1, -0.4, 4.0], [1.6, 0, -0.5], [2.0, 0, -3.5]],
                  alpha=[[0, 0], [0.25, 1], [1.35, 1], [1.75, 0], [2.0, 0]], rot=[[0, -10], [0.55, 10], [1.1, -8], [2.0, -10]])),
], icon=(0, 4, 18), desc='Бледно-синие дрожащие линии и маленький дух, вылетающий вверх')

emote('awkward', 'Неловкость', 4.5, 'side', [
    L('sweat', (4.4, 5.9), (5.7, 2.2, 3.2), pop=False, ease='smooth',
      tracks=dict(scale=[[0, 0.15], [0.7, 1.12], [0.9, 1.0], [2.3, 1.0], [2.42, 1.15, 0.8], [2.55, 0.92, 1.08], [2.7, 1.0]],
                  pos=[[0, 0, 1.0], [0.9, 0, 1.0], [2.3, 0, -2.4], [2.48, 0, -1.6], [2.66, 0, -2.4], [4.5, 0, -2.7]],
                  alpha=[[0, 0], [0.1, 1]])),
], icon=(2.5, 1, 16), desc='Огромная капля пота у виска: растёт, сползает вниз и отскакивает')

emote('suspicion', 'Подозрение', 4.5, 'above', [
    L('bubble', (1.1, 1.1), (2.4, 5.4, 1)),
    L('bubble', (1.5, 1.5), (3.4, 6.9, 1), start=0.1),
    L('sus_cloud', (9.2, 6.3), (5.2, 10.6, 0), start=0.2),
    L('sus_eyes_frame', (6.0, 2.14), (5.2, 10.6, 0.15), start=0.3),
    L('pupil', (1.05, 0.7), (5.2, 10.3, 0.3), start=0.3, loop=2.4, ease='smooth',
      tracks=dict(pos=[[0, -0.85, 0], [0.55, -0.85, 0], [0.75, 0.85, 0], [1.45, 0.85, 0], [1.65, -0.85, 0], [2.4, -0.85, 0]]),
      instances=[I((-1.5, 0, 0)), I((1.5, 0, 0))]),
], icon=(3.5, 6.5, 16), desc='Прищуренные глаза в облачке, которые подозрительно смотрят влево и вправо')

emote('smug', 'Самодовольство', 4.5, 'face', [
    L('sunglasses', (8.6, 2.6), (0, -0.2, FZ + 0.03), space='face', pop=False, ease='smooth',
      tracks=dict(pos=[[0, 0, 9], [0.35, 0, 0], [0.45, 0, 0.4], [0.56, 0, 0], [4.5, 0, -0.15]],
                  rot=[[0, -24], [0.35, 0], [0.47, -4], [0.7, -3.5]], alpha=[[0, 0], [0.06, 1]])),
    L('glint', (2.2, 2.2), (-3.0, 0.2, FZ + 0.06), space='face', start=0.6, loop=1.8, pop=False,
      tracks=dict(pos=[[0, 0, 0], [0.45, 6.0, 0], [1.8, 6.0, 0]], alpha=[[0, 0], [0.05, 1], [0.4, 1], [0.45, 0], [1.8, 0]],
                  rot=[[0, 0], [0.45, 90]])),
    L('sparkle', (2.2, 2.2), (5.6, 1.6, 3), start=0.7, loop=1.8, secondary=True,
      tracks=dict(scale=[[0, 0.2], [0.2, 1.2], [0.5, 0.2], [1.8, 0.2]], alpha=[[0, 0], [0.1, 1], [0.5, 0], [1.8, 0]])),
], icon=(0, 0, 14), desc='Кривоватые тёмные очки, опускающиеся сверху, и блик по краю')

emote('sleepy', 'Сонливость', 6.0, 'above', [
    L('zed', (3.0, 3.0), (4.0, 5.2, 0), loop=2.4, pop=False, ease='smooth',
      tracks=dict(pos=[[0, 0, 0], [0.8, 1.6, 2.4], [1.6, 2.8, 4.8], [2.4, 4.4, 7.2]], alpha=[[0, 0], [0.3, 1], [1.8, 1], [2.4, 0]],
                  scale=[[0, 0.4], [2.4, 1.15]], rot=[[0, -16], [1.2, 12], [2.4, -10]]),
      instances=[I(phase=0, scale=0.8), I(phase=0.8, scale=1.0), I(phase=1.6, scale=1.25)]),
], icon=(4, 8, 16), desc='Три символа Z разного размера, которые последовательно всплывают')

orbit = []
for i in range(9):
    a = i / 8 * 2 * math.pi
    orbit.append([round(1.4 * i / 8, 4), round(5.6 * math.sin(a), 3), round(0.6 * math.cos(a * 2), 3), round(3.2 * math.cos(a), 3)])
emote('dizzy', 'Головокружение', 4.5, 'face', [
    L('spiral', (2.6, 2.6), (2.0, -0.4, FZ + 0.02), space='face', loop=0.8,
      tracks=dict(rot=[[0, 0], [0.8, -360]]), instances=[I(), I(flip=True)]),
    L('star_small', (2.0, 2.0), (0, 6.2, 0), loop=1.4,
      tracks=dict(pos=orbit, rot=[[0, 0], [1.4, 360]]), instances=[I(phase=0), I(phase=1.4/3), I(phase=2.8/3)]),
], icon=(0, 2.5, 16), desc='Спирали в глазах и маленькие звёзды, кружащие над головой')

emote('facepalm', 'Фейспалм', 3.5, 'face', [
    L('palm', (6.6, 7.4), (0.6, 0.4, FZ + 0.25), space='face', pop=False, ease='smooth',
      tracks=dict(pos=[[0, 10, -4], [0.24, 0.6, 0], [0.3, 0, 0], [1.0, 0, 0], [3.5, 0, -1.0]],
                  rot=[[0, -55], [0.24, -10], [0.3, -6]],
                  scale=[[0, 1], [0.24, 1], [0.28, 1.1, 0.9], [0.4, 1]], alpha=[[0, 0], [0.06, 1]])),
    L('impact', (3.8, 3.8), (3.4, 4.8, 4.6), start=0.26, pop=False,
      tracks=dict(scale=[[0, 0], [0.07, 1.35], [0.2, 1], [0.5, 0.85], [0.7, 0]], alpha=[[0, 1], [0.5, 1], [0.7, 0]], rot=[[0, 0], [0.7, 25]])),
    L('star_small', (1.5, 1.5), (3.4, 4.8, 4.7), start=0.28, pop=False, secondary=True,
      tracks=dict(pos=[[0, 0, 0], [0.6, 3.0, 1.2]], alpha=[[0, 1], [0.4, 1], [0.6, 0]], rot=[[0, 0], [0.6, 180]]),
      instances=[I(), I(flip=True, offset=(-6.8, 0, 0))]),
], icon=(1, 1, 16), desc='Мультяшная ладонь хлопает по лбу, появляется звёздочка удара')

emote('mischief', 'Озорство', 4.5, 'above', [
    L('horn', (2.6, 3.25), (2.7, 5.6, 1.2), pop=False, ease='smooth',
      tracks=dict(pos=[[0, 0, -3.2], [0.15, 0, 0.7], [0.26, 0, 0]], scale=[[0, 0.3, 1.6], [0.15, 0.85, 1.2], [0.26, 1, 1]]),
      instances=[I(flip=True), I()]),
    L('bubble', (1.1, 1.1), (3.8, 5.0, 1), start=0.3),
    L('bubble', (1.5, 1.5), (5.0, 6.4, 1), start=0.4),
    L('grin_cloud', (8.0, 5.6), (7.0, 9.6, 0), start=0.5, loop=3.0, ease='smooth', tracks=dict(pos=[[0, 0, 0], [1.5, 0, 0.35], [3.0, 0, 0]])),
    L('grin', (4.8, 2.4), (7.0, 9.4, 0.15), frames=3, start=0.6, loop=2.2,
      tracks=dict(frame=[[0, 0], [0.5, 1], [1.4, 2], [1.75, 1]], scale=[[0, 1, 1], [0.5, 1.12, 1], [1.4, 1.12, 1], [2.2, 1, 1]],
                  pos=[[0, 0, 0], [1.1, 0, 0.35], [2.2, 0, 0]])),
], icon=(3.5, 6, 16), desc='Фиолетовые рожки выскакивают, хитрая улыбка в облачке растягивается и подмигивает')
assert len(E) == 20, len(E)

# ---- exaggeration pass: billboard effects bigger and pushed a bit outward
for _e in E:
    for _l in _e['layers']:
        if _l['space'] == 'billboard':
            _l['size'] = [round(v*1.3, 3) for v in _l['size']]
            _l['pos'] = [round(_l['pos'][0]*1.12, 3), round(_l['pos'][1]*1.08 if _l['pos'][1] > 4 else _l['pos'][1], 3), _l['pos'][2]]
            for _i in _l.get('instances', []):
                _i['offset'] = [round(_i['offset'][0]*1.12, 3), round(_i['offset'][1]*1.08, 3), _i['offset'][2]]
