import numpy as np, os, sys
sys.path.insert(0, '/data/art')
from px import Canvas, hexc, shift, K, outline_col
from PIL import Image
OUT = '/data/emotes-mod/src/main/resources/assets/rubycon_emotes/textures/emote'
OL = '#1f0f1c'
S = {}
def save(name, c):
    im = c.image() if isinstance(c, Canvas) else c
    im.save(f'{OUT}/{name}.png'); S[name] = im
def extrude(c, m, col, dx=1, dy=1.5):
    """3D-ish extrusion: dark copy shifted down-right under the shape"""
    e = np.zeros_like(m)
    for i in range(1, int(round(dy*K))+1):
        e |= shift(m, int(round(i*dx/dy)), i)
    c.put(e & ~m, col)
def face_cute(c, cx, cy, sc=1.0, mood='sad', col='#2a1530'):
    """tiny kawaii face"""
    ex = 3.2*sc
    if mood == 'sad':
        for sx in (-1, 1):
            c.put(c.ellipse(cx+sx*ex, cy, 1.1*sc, 1.4*sc), col)
            c.put(c.capsule(cx+sx*(ex+1.6*sc), cy-2.4*sc, cx+sx*(ex-1.0*sc), cy-1.7*sc, 0.45*sc), col)
        c.put(c.ring(cx, cy+4.2*sc, 2.0*sc, 0.9*sc) & (c.Y < cy+3.2*sc), col)
    elif mood == 'happy':
        for sx in (-1, 1):
            c.put(c.ring(cx+sx*ex, cy+0.6*sc, 1.4*sc, 0.8*sc) & (c.Y < cy+0.5*sc), col)
        c.put(c.ellipse(cx, cy+2.2*sc, 1.6*sc, 1.2*sc) & (c.Y > cy+2.0*sc), '#c8325a')
    elif mood == 'o':
        for sx in (-1, 1): c.put(c.ellipse(cx+sx*ex, cy, 1.1*sc, 1.5*sc), col)
        c.put(c.ellipse(cx, cy+3*sc, 1.3*sc, 1.7*sc), col)
    for sx in (-1, 1):
        c.put(c.ellipse(cx+sx*(ex+1.6*sc), cy+1.9*sc, 1.3*sc, 0.7*sc), (255, 120, 150, 200))

# 1. anger vein 💢 — thick, glossy
c = Canvas(32, 32); m = np.zeros((c.H, c.W), bool)
for sx in (-1, 1):
    for sy in (-1, 1):
        cx, cy = 16 + sx*12.5, 16 + sy*12.5
        r = c.ring(cx, cy, 11.4, 5.4)
        r &= ((c.X-16)*sx > 1.4) & ((c.Y-16)*sy > 1.4)
        m |= r
extrude(c, m, '#7a0a22', 0.6, 1.2)
c.part(m, '#ff2f45'); c.outline(OL); save('vein', c)

# steam puff
c = Canvas(26, 22)
m = c.circle(8, 14, 6.5) | c.circle(15, 9.5, 7) | c.circle(19.5, 15, 5) | c.circle(9.5, 7.5, 4.5) | c.rect(7, 13, 20, 20)
c.part(m, '#eef2fb', dome=0.8); c.outline('#4a5272'); save('steam', c)

# rage shade (face, upper half, purple gloom lines) — semi-transparent
c = Canvas(32, 14)
for i, x in enumerate(range(2, 32, 4)):
    c.put(c.rect(x, 0, x+2, 8 + (i % 3) * 2.5), (70, 20, 70, 160))
c.put(c.rect(0, 0, 32, 2.5), (70, 20, 70, 120))
save('rage_shade', c)

# laugh eyes  > <  bold with light rim
c = Canvas(32, 12)
m = c.capsule(3.5, 1.6, 11.5, 6, 1.7) | c.capsule(11.5, 6, 3.5, 10.4, 1.7) | c.capsule(28.5, 1.6, 20.5, 6, 1.7) | c.capsule(20.5, 6, 28.5, 10.4, 1.7)
c.put(m, '#1a0e1e'); save('laugh_eyes', c)

# joy tear (glossy drop)
c = Canvas(14, 18)
m = c.drop(7, 11.5, 5.2, 11)
c.part(m, '#4fb8ff'); c.outline('#0f2f63'); save('tear', c)

# rain cloud with a sad little face
c = Canvas(40, 28)
m = c.circle(11, 16, 8) | c.circle(20, 10.5, 9) | c.circle(29, 15, 8) | c.rect(9, 14, 32, 24) | c.circle(33, 19, 5) | c.circle(7, 20, 4.5)
m &= c.Y < 25.5
c.part(m, '#8a97bd', dome=0.9)
face_cute(c, 20, 16.5, 0.9, 'sad')
c.outline('#232842'); save('raincloud', c)

# raindrop
c = Canvas(8, 12)
m = c.drop(4, 8, 2.8, 6.8)
c.part(m, '#3d8ff0', gloss=False); c.put(c.rect(2.5, 6.5, 3.5, 8.5) & m, '#d6efff'); c.outline('#10275a'); save('raindrop', c)

# tear stream: 4 frames, 10x40, wide wavy waterfall
frames = []
for f in range(4):
    c = Canvas(10, 40)
    m = c.rect(2, 0, 8, 33)
    for k in range(6):
        y = (k*7 + f*1.75) % 42 - 1
        m |= c.ellipse(5, y, 4.1, 2.6)
    m |= c.circle(5, 34.5, 4.2)
    m &= c.rect(0.5, 0, 9.5, 40)
    c.part(m, '#6cc8ff', gloss=False, dome=0.7)
    for k in range(4):
        y = (k*10 + f*2.5) % 34 + 1
        c.put(c.rect(3, y, 4, y+3.5) & m, '#ffffff')
        c.put(c.rect(6.2, y+5, 7, y+6.5) & m, '#d9f3ff')
    c.put(c.circle(3.6, 33.5, 1.0), '#ffffff')
    c.outline('#123a75')
    frames.append(c.img)
save('tear_stream', Image.fromarray(np.concatenate(frames, 0), 'RGBA'))

# exclamation (big, bold, extruded)
def exclam(w, h, col, ext):
    c = Canvas(w, h)
    bar = c.poly([(w*0.18, 2), (w*0.82, 2), (w*0.64, h*0.64), (w*0.36, h*0.64)]) | c.ellipse(w/2, 4.2, w*0.32, 3)
    dot = c.circle(w/2, h - w*0.3 - 2.2, w*0.27)
    m = bar | dot
    extrude(c, m, ext, 0.5, 1.4)
    c.part(bar, col); c.part(dot, col); c.outline(OL); return c
save('exclam', exclam(16, 32, '#ffd02a', '#a8520a'))
save('exclam_red', exclam(12, 24, '#ff4646', '#7a0c22'))

# shock lines (zig-zag bolts, cream with purple outline)
c = Canvas(48, 48); m = np.zeros((c.H, c.W), bool)
for i, a in enumerate(range(0, 360, 40)):
    r = np.radians(a + 8); r2 = np.radians(a + 20); L0 = 13.5 + (i % 2) * 2.5
    p0 = (24 + L0*np.cos(r), 24 + L0*np.sin(r)); p1 = (24 + (L0+4)*np.cos(r2), 24 + (L0+4)*np.sin(r2)); p2 = (24 + (L0+8.5)*np.cos(r), 24 + (L0+8.5)*np.sin(r))
    m |= c.capsule(*p0, *p1, 1.0) | c.capsule(*p1, *p2, 1.0)
c.put(m, '#ffffff'); c.outline('#3a1250'); save('shock_lines', c)

# question mark (bold extruded)
c = Canvas(24, 32)
hook = c.ring(12, 10.5, 9, 5.2) & ~((c.X < 11.5) & (c.Y > 10))
stem = c.rect(9.4, 15, 14.6, 22.5) | c.poly([(9.4, 15.5), (16.5, 13), (19.6, 17), (14.6, 18.5)])
m = hook | stem; dot = c.circle(12, 27.4, 3.1)
extrude(c, m | dot, '#13428a', 0.5, 1.4)
c.part(m, '#45c4ff'); c.part(dot, '#45c4ff'); c.outline(OL); save('question', c)

# clouds
def cloud(w, h, base, ol):
    c = Canvas(w, h)
    m = c.ellipse(w/2, h/2+1.5, w/2-3, h/2-4.5) | c.circle(w*0.3, h*0.44, h*0.3) | c.circle(w*0.55, h*0.35, h*0.34) | c.circle(w*0.76, h*0.5, h*0.28) | c.circle(w*0.22, h*0.66, h*0.24) | c.circle(w*0.8, h*0.7, h*0.2)
    c.part(m, base, dome=0.6, gloss=False); c.outline(ol); return c
save('thought_cloud', cloud(40, 28, '#f6f7ff', '#3b3560'))
c = Canvas(8, 8); c.part(c.circle(4, 4, 3), '#6b5aa8', gloss=False); save('dot', c)
c = Canvas(8, 8); c.part(c.circle(4, 4, 2.7), '#f6f7ff', gloss=False); c.outline('#3b3560'); save('bubble', c)

# blush
c = Canvas(24, 14)
c.put(c.ellipse(12, 7, 11, 6), (255, 105, 150, 140))
c.put(c.ellipse(12, 7, 7, 3.8), (255, 90, 140, 170))
for x in (4, 10, 16):
    c.put(c.capsule(x+4, 2.5, x+1, 11.5, 1.15), (240, 40, 105, 255))
save('blush', c)

# hearts
def heart(w, col):
    c = Canvas(w, w*0.92)
    m = c.heart(w/2, w*0.46, w*0.4)
    extrude(c, m, outline_col(col), 0.4, 1.0)
    c.part(m, col); c.outline(OL); return c
save('heart', heart(32, '#ff3d6e'))
save('heart_pink', heart(20, '#ff86b4'))

# gold star (with shine)
c = Canvas(32, 32)
m = c.star(16, 17, 15, 7)
extrude(c, m, '#8a3c06', 0.4, 1.2)
c.part(m, '#ffc21f'); c.outline('#4a1f05'); save('star_gold', c)

# sparkles
c = Canvas(16, 16); m = c.star(8, 8, 7.6, 1.7, n=4)
c.put(m, '#fff6c8'); c.put(c.star(8, 8, 4, 1, n=4), '#ffffff'); c.outline('#c07a12'); save('sparkle', c)
c = Canvas(16, 16); m = c.star(8, 8, 7.6, 1.5, n=4); c.put(m, (255, 255, 255, 255)); c.put(c.circle(8, 8, 2), (255, 255, 255, 255)); save('glint', c)

# fear lines
c = Canvas(32, 20)
for i, x in enumerate(range(1, 32, 3.5) if False else np.arange(1, 32, 3.6)):
    c.put(c.rect(x, 0, x+1.6, 11 + (i % 3) * 3), (80, 120, 255, 150))
c.put(c.rect(0, 0, 32, 3), (80, 120, 255, 100))
save('fear_lines', c)

# ghost — cute, wavy, "O" mouth, blush
c = Canvas(24, 28)
m = c.circle(12, 11, 9.2) | c.rect(2.8, 11, 21.2, 21.5)
for x in (2.8, 8.9, 15):
    m |= c.ellipse(x+3.1, 21.5, 3.1, 4.2) & (c.Y > 21)
m |= c.capsule(3, 14, 0.8, 10, 1.6) | c.capsule(21, 14, 23.2, 10.5, 1.6)
c.part(m, '#eef1ff', dome=0.8)
face_cute(c, 12, 11, 1.0, 'o', '#1c1838')
c.outline('#2f2f66'); save('ghost', c)

# huge sweat drop
c = Canvas(24, 32)
m = c.drop(12, 20.5, 9.8, 19.5)
c.part(m, '#5cc4ff', dome=1.0)
c.put(c.ellipse(7.5, 18.5, 1.9, 4.4, 18) & m, '#ffffff'); c.put(c.circle(8.5, 25, 1.2) & m, '#ffffff')
c.outline('#0e2f66'); save('sweat', c)

# suspicious cloud + eyes
save('sus_cloud', cloud(44, 30, '#fff4dc', '#4a3220'))
c = Canvas(28, 10)
for cx in (7, 21):
    eye = c.ellipse(cx, 6.3, 5.6, 2.4) & (c.Y > 4.4)
    c.put(eye, '#ffffff'); c.inline(eye, '#2a1a10'); c.put(c.poly([(cx-6.5, 3.2), (cx+6.5, 2.2 if cx > 14 else 4.6), (cx+6.5, 4.8 if cx > 14 else 6.0), (cx-6.5, 5.4 if cx > 14 else 4.4)]), '#2a1a10')
save('sus_eyes_frame', c)
c = Canvas(6, 4); c.put(c.rect(1, 0, 5, 4), '#2a1a10'); c.put(c.rect(1.5, 0.5, 2.5, 1.5), '#ffffff'); save('pupil', c)

# sunglasses (deal-with-it) with lens gradient + reflection
c = Canvas(40, 12)
lensL = c.poly([(1.5, 1), (17.5, 1), (16.5, 9), (12.5, 11.2), (5.5, 11.2), (2.5, 8)])
lensR = c.poly([(22.5, 1), (38.5, 1), (37.5, 8), (34.5, 11.2), (27.5, 11.2), (23.5, 9)])
c.put(lensL | lensR | c.rect(15, 1, 25, 4) | c.rect(0.5, 1, 39.5, 3.4), '#120c1c')
for L, x0 in ((lensL, 2), (lensR, 23)):
    c.put(L & (c.Y > 7), '#2c2148')
    c.put(L & c.capsule(x0+3, 4.5, x0+6, 7.5, 0.9), '#8c84d8'); c.put(L & c.capsule(x0+7, 4.5, x0+8.5, 6, 0.6), '#b9b2f0')
save('sunglasses', c)

# Z — extruded letter
def zed(w, col):
    c = Canvas(w, w); k = w/24
    m = c.poly([(3*k, 3*k), (21*k, 3*k), (21*k, 8*k), (11*k, 16*k), (21*k, 16*k), (21*k, 21*k), (3*k, 21*k), (3*k, 16*k), (13*k, 8*k), (3*k, 8*k)])
    extrude(c, m, '#3a1f8a', 0.6, 1.6)
    c.part(m, col); c.outline('#1c0f44'); return c
save('zed', zed(24, '#a98bff'))

# spiral eye
c = Canvas(16, 16)
c.put(c.circle(8, 8, 7.6), '#ffffff')
t = np.linspace(0.3, 4.3*np.pi, 500); m = np.zeros((c.H, c.W), bool)
for a in t:
    r = a*0.5; m |= c.circle(8 + r*np.cos(a), 8 + r*np.sin(a), 0.62)
c.put(m & c.circle(8, 8, 7.6), '#2b1838'); c.outline(OL); save('spiral', c)

# small star
c = Canvas(14, 14)
m = c.star(7, 7.5, 6.6, 3.0); c.part(m, '#ffe35a'); c.outline('#6b3a0a'); save('star_small', c)

# palm
c = Canvas(32, 36)
palm = c.ellipse(16, 22, 10.2, 9.6)
fingers = c.capsule(9, 8, 9.6, 18, 3.1) | c.capsule(14.6, 4.8, 14.6, 17, 3.2) | c.capsule(20.2, 5.8, 19.6, 17, 3.1) | c.capsule(25.2, 10, 24.2, 19, 2.8)
thumb = c.capsule(5.2, 21, 1.8, 13.5, 3.1)
cuff = c.rect(8.5, 27.5, 23.5, 36)
c.part(cuff, '#3a86d0', gloss=False)
c.put(c.rect(8.5, 27.5, 23.5, 29), '#e8f2ff')
c.part(palm | fingers | thumb, '#ffc596', gloss=False)
for x0 in (11.9, 17.4, 22.3):
    c.put(c.rect(x0, 12.5, x0+0.9, 17) & (palm | fingers), '#d4875a')
c.put(c.ring(16, 19, 5, 0.9) & (c.Y > 21) & palm, '#e0a07a')
c.outline('#3a1a10'); save('palm', c)

# impact star
c = Canvas(24, 24)
m = c.star(12, 12, 11.6, 5.2, n=7, rot=-80)
c.part(m, '#fff07a', gloss=False); c.put(c.star(12, 12, 6, 3, n=7, rot=-80), '#ffffff'); c.outline('#7a3a00'); save('impact', c)

# horn (glossy, curved)
c = Canvas(16, 20)
m = c.poly([(2.5, 19.5), (13.5, 19.5), (12.8, 13), (10, 7.5), (6, 3.5), (3.2, 1), (4.2, 6), (4.5, 10), (2.8, 14)])
c.part(m, '#a34dff'); c.put(c.rect(2.5, 16.5, 13.5, 19.5) & m, '#6a24c4'); c.outline('#24073f'); save('horn', c)

# mischief cloud + grin frames
save('grin_cloud', cloud(40, 28, '#f3e8ff', '#3b1f66'))
frames = []
for f in range(3):
    c = Canvas(24, 12)
    if f == 0:
        mouth = c.ring(12, -4.5, 13.5, 2.4) & (c.Y > 5)
        eyes = c.capsule(5.5, 3.2, 9, 1.8, 1.05) | c.capsule(15, 1.8, 18.5, 3.2, 1.05)
    else:
        mouth = c.ellipse(12, 4.8, 10.4, 6) & (c.Y > 5.0)
        eyes = c.capsule(5, 3.6, 9, 1.6, 1.05) | (c.capsule(15, 1.6, 19, 3.6, 1.05) if f == 1 else c.capsule(15, 2.6, 19, 2.6, 1.0))
    c.put(mouth, '#3b1060')
    if f > 0:
        teeth = mouth & (c.Y < 7.4)
        c.put(teeth, '#ffffff')
        for x in (8, 12, 16): c.put(c.rect(x, 5, x+0.5, 7.4) & teeth, '#c9b8e8')
        c.put(mouth & (c.Y > 9) & (np.abs(c.X-12) < 3), '#ff5a8a')
    c.put(eyes, '#3b1060')
    frames.append(c.img)
save('grin', Image.fromarray(np.concatenate(frames, 0), 'RGBA'))

print(len(S), 'sprites')
sheet = Image.new('RGBA', (8*150, ((len(S)+7)//8)*150), (60, 64, 80, 255))
for i, (n, im) in enumerate(S.items()):
    k = max(1, min(140//im.width, 140//im.height))
    sheet.alpha_composite(im.resize((im.width*k, im.height*k), Image.NEAREST), ((i % 8)*150+5, (i//8)*150+5))
sheet.convert('RGB').save('/data/art/sheet.jpg', quality=90)
