import sys, json, os
sys.path.insert(0, '/data/art')
from emotes import E
R = '/data/emotes-mod/src/main/resources'
os.makedirs(f'{R}/assets/rubycon_emotes/emotes', exist_ok=True)
os.makedirs(f'{R}/rubycon_emotes', exist_ok=True)
for e in E:
    d = dict(id=e['id'], name=e['name'], description=e['desc'], duration=e['duration'], placement=e['placement'],
             scale=1.0, offset=[0, 0, 0], icon=f"rubycon_emotes:textures/emote/icon/{e['id']}.png", layers=[])
    for ly in e['layers']:
        l = dict(ly); l['texture'] = f"rubycon_emotes:textures/emote/{l.pop('tex')}.png"
        d['layers'].append(l)
    json.dump(d, open(f"{R}/assets/rubycon_emotes/emotes/{e['id']}.json", 'w'), ensure_ascii=False, indent=1)
idx = dict(comment='Список эмоций. Копию можно положить в config/rubycon_emotes-index.json для изменения состава/длительности на сервере.',
           emotes=[dict(id=e['id'], name=e['name'], duration=e['duration']) for e in E])
json.dump(idx, open(f'{R}/rubycon_emotes/index.json', 'w'), ensure_ascii=False, indent=1)
print('ok')
